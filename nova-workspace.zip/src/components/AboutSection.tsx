import React from 'react';
import {
  Coffee,
  Heart,
  Users,
  Award,
  Sparkles,
  Leaf,
  Clock,
  Compass
} from 'lucide-react';
import { CAFE_INFO } from '../data/cafeData';

export const AboutSection: React.FC = () => {
  const highlights = [
    {
      icon: Coffee,
      title: "Direct-Trade Small Batch Roastery",
      description: "We source green coffee directly from woman-led farm cooperatives in Ethiopia, Colombia, and Guatemala, roasting in 12kg micro-batches on our vintage Diedrich roaster."
    },
    {
      icon: Award,
      title: "Wild Yeast Organic Sourdough",
      description: "Our bread starters have been gently nurtured for over 7 years. Every loaf, brioche, and pastry undergoes a 36-hour slow cold fermentation for exquisite crust and gentle digestion."
    },
    {
      icon: Users,
      title: "Community & Work-Friendly Haven",
      description: "Whether you need a sunlit corner with Gigabit Wi-Fi to finish your thesis, or a leafy patio table to catch up with friends and pups, our doors are open."
    },
    {
      icon: Leaf,
      title: "Zero Waste & Sustainable Spirit",
      description: "100% compostable takeaway packaging, spent coffee grounds donated to local community gardens, and solar-assisted water heating."
    }
  ];

  return (
    <section id="about" className="py-16 bg-[#f4ede3] border-t border-[#e2d5c3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Story Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0] inline-flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#94552b]" />
              Our Heritage & Philosophy
            </span>

            <h2 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl font-bold text-[#271b12] tracking-tight leading-tight">
              Rooted in Elmwood. Crafted for genuine connection.
            </h2>

            <p className="text-sm sm:text-base text-[#5f493b] leading-relaxed">
              Founded in 2018 in what was once a 1920s brick printshop, <strong>Velvet Roast Cafe & Bakehouse</strong> was born from a simple belief: that a neighborhood cafe should be a sanctuary of exceptional sensory craft, warm hospitality, and community vitality.
            </p>

            <p className="text-sm sm:text-base text-[#5f493b] leading-relaxed">
              We never cut corners. Our espresso shots are weighed to the tenth of a gram, our milk is steamed to silky microfoam temperature, and our pastries are rolled by hand each morning before sunrise.
            </p>

            {/* Quick Quote Card */}
            <div className="p-4 rounded-2xl bg-white border border-[#dfd0bd] shadow-xs flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=150&q=80"
                alt="Head Barista & Co-Founder"
                className="w-12 h-12 rounded-full object-cover border border-[#e2d5c3]"
              />
              <div className="text-xs">
                <p className="italic text-[#4a3528] font-medium leading-snug">
                  &ldquo;Coffee isn&apos;t just fuel—it&apos;s a brief pause in a busy world where craft, aroma, and human connection meet.&rdquo;
                </p>
                <span className="text-[#884e27] font-bold block mt-1">
                  — Mateo & Claire, Co-Founders & Head Baristas
                </span>
              </div>
            </div>
          </div>

          {/* Photo Gallery Grid */}
          <div className="lg:col-span-6 grid grid-cols-2 gap-3.5">
            <div className="space-y-3.5">
              <div className="rounded-2xl overflow-hidden aspect-4/5 shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=600&q=80"
                  alt="Espresso Machine Pour"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="rounded-2xl overflow-hidden aspect-square shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80"
                  alt="Fresh Baked Brioche & Pastries"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>

            <div className="space-y-3.5 pt-6">
              <div className="rounded-2xl overflow-hidden aspect-square shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=600&q=80"
                  alt="Sunlit Cafe Seating"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="rounded-2xl overflow-hidden aspect-4/5 shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=600&q=80"
                  alt="Barista Latte Art Pour"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 4 Pillars Highlight */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4">
          {highlights.map((h, i) => {
            const Icon = h.icon;
            return (
              <div
                key={i}
                className="bg-white p-5 rounded-3xl border border-[#e5d8c6] shadow-xs space-y-2.5"
              >
                <div className="w-9 h-9 rounded-xl bg-[#f4ece0] text-[#884e27] flex items-center justify-center font-bold">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-serif-title font-bold text-base text-[#271b12]">
                  {h.title}
                </h3>
                <p className="text-xs text-[#6e5849] leading-relaxed">
                  {h.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
