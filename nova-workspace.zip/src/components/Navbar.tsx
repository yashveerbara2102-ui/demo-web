import React, { useState } from 'react';
import {
  Coffee,
  ShoppingBag,
  Sparkles,
  Menu as MenuIcon,
  X,
  Code,
  Clock,
  Phone,
  Compass
} from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenEmbedModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSection,
  setActiveSection,
  cartCount,
  onOpenCart,
  onOpenEmbedModal
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'menu', label: 'Menu & Food' },
    { id: 'special', label: 'Custom Brew Lab', isSpecial: true },
    { id: 'suggest', label: 'Barista Picks' },
    { id: 'about', label: 'About Us' },
    { id: 'reviews', label: 'Guest Reviews' },
    { id: 'contact', label: 'Hours & Contact' },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#faf7f2]/95 backdrop-blur-md border-b border-[#e7decb] shadow-xs transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-[#4a3528] text-[#f7efe6] text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-4 flex-wrap">
        <span className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-[#e2b77c]" />
          <span>Open Today: 6:30 AM – 7:00 PM</span>
        </span>
        <span className="hidden sm:inline text-[#b89f8a]">•</span>
        <span className="hidden sm:inline">Fresh Sourdough Bakes fresh out of the oven at 7:30 AM & 12 PM</span>
        <span className="hidden md:inline text-[#b89f8a]">•</span>
        <button
          onClick={onOpenEmbedModal}
          className="inline-flex items-center gap-1 text-[#e2b77c] hover:text-white underline cursor-pointer transition-colors"
        >
          <Code className="w-3 h-3" />
          <span>Google Sites Embed Code</span>
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('hero')}
            className="flex items-center gap-3 text-left cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#784d31] to-[#3a2214] flex items-center justify-center text-[#faebd7] shadow-md shadow-[#784d31]/20 group-hover:scale-105 transition-transform">
              <Coffee className="w-5 h-5 text-[#f5dbbe]" />
            </div>
            <div>
              <span className="font-serif-title font-bold text-xl sm:text-2xl text-[#2d1f15] tracking-tight block leading-tight">
                Velvet Roast
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#8b6545] font-semibold block">
                Cafe & Bakehouse
              </span>
            </div>
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                  link.isSpecial
                    ? 'bg-[#834f2a]/10 text-[#834f2a] hover:bg-[#834f2a]/15 font-semibold'
                    : activeSection === link.id
                    ? 'text-[#2d1f15] bg-[#ebdccb] font-semibold'
                    : 'text-[#5c493c] hover:text-[#2d1f15] hover:bg-[#ebdccb]/60'
                }`}
              >
                {link.isSpecial && <Sparkles className="w-3.5 h-3.5 text-[#b06a35]" />}
                {link.label}
              </button>
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Embed Helper button */}
            <button
              onClick={onOpenEmbedModal}
              title="Get Google Sites embed code"
              className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-[#73513a] bg-[#ede3d4] hover:bg-[#dfd0bd] border border-[#d8c7b0] px-3 py-2 rounded-xl transition-colors cursor-pointer"
            >
              <Code className="w-3.5 h-3.5 text-[#834f2a]" />
              <span>Embed Mode</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative flex items-center gap-2 bg-[#4a3528] hover:bg-[#38261b] active:scale-95 text-[#f7efe6] px-4 py-2 rounded-xl text-sm font-semibold transition-all shadow-sm cursor-pointer"
              aria-label="View Cart"
            >
              <ShoppingBag className="w-4 h-4 text-[#e2b77c]" />
              <span className="hidden sm:inline">Order Bag</span>
              {cartCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-[#c85a2b] text-white text-[11px] font-bold flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-[#4a3528] hover:bg-[#ebdccb] cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#faf7f2] border-b border-[#e7decb] px-4 pt-3 pb-6 space-y-2 shadow-lg">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-colors flex items-center justify-between ${
                link.isSpecial
                  ? 'bg-[#834f2a]/10 text-[#834f2a] font-semibold'
                  : 'text-[#4a3528] hover:bg-[#ebdccb]'
              }`}
            >
              <span className="flex items-center gap-2">
                {link.isSpecial && <Sparkles className="w-4 h-4 text-[#b06a35]" />}
                {link.label}
              </span>
              <span className="text-xs text-[#8b6545]">&rarr;</span>
            </button>
          ))}
          <div className="pt-2 border-t border-[#ebdccb] flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenEmbedModal();
              }}
              className="w-full text-center py-2.5 text-xs font-semibold text-[#664b38] bg-[#ebdccb] rounded-xl flex items-center justify-center gap-2"
            >
              <Code className="w-4 h-4" />
              <span>Copy Google Sites Iframe Embed Code</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
