import React, { useState } from 'react';
import {
  Sparkles,
  Zap,
  Heart,
  Leaf,
  Coffee,
  ThumbsUp,
  MessageSquarePlus,
  Send,
  CheckCircle2,
  Tag,
  ArrowRight
} from 'lucide-react';
import { MoodPairing, CommunitySuggestion, MenuItem } from '../types';
import { MOOD_PAIRINGS, INITIAL_COMMUNITY_SUGGESTIONS, MENU_ITEMS } from '../data/cafeData';

interface SuggestSectionProps {
  onAddPairingToCart: (dishItem: MenuItem, drinkItem: MenuItem, bundlePrice: number) => void;
}

export const SuggestSection: React.FC<SuggestSectionProps> = ({ onAddPairingToCart }) => {
  const [activeMoodId, setActiveMoodId] = useState<string>(MOOD_PAIRINGS[0].id);
  const [communitySuggestions, setCommunitySuggestions] = useState<CommunitySuggestion[]>(INITIAL_COMMUNITY_SUGGESTIONS);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('Drink Creation');
  const [newAuthor, setNewAuthor] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [showSubmitSuccess, setShowSubmitSuccess] = useState(false);
  const [addedPairingNotice, setAddedPairingNotice] = useState<string | null>(null);

  const selectedPairing = MOOD_PAIRINGS.find((p) => p.id === activeMoodId) || MOOD_PAIRINGS[0];

  const handleUpvote = (id: string) => {
    setCommunitySuggestions((prev) =>
      prev.map((sug) => {
        if (sug.id === id) {
          const hasVoted = sug.hasUpvoted;
          return {
            ...sug,
            upvotes: hasVoted ? sug.upvotes - 1 : sug.upvotes + 1,
            hasUpvoted: !hasVoted,
          };
        }
        return sug;
      })
    );
  };

  const handleSubmitSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const newEntry: CommunitySuggestion = {
      id: `sug-${Date.now()}`,
      title: newTitle.trim(),
      category: newCategory,
      author: newAuthor.trim() || 'Valued Neighbor',
      date: 'Just now',
      description: newDesc.trim(),
      upvotes: 1,
      hasUpvoted: true,
      status: 'In Review',
    };

    setCommunitySuggestions([newEntry, ...communitySuggestions]);
    setNewTitle('');
    setNewAuthor('');
    setNewDesc('');
    setShowSubmitSuccess(true);
    setTimeout(() => setShowSubmitSuccess(false), 3500);
  };

  const handleOrderPairing = (pairing: MoodPairing) => {
    // Find matching items from menu data
    const dish = MENU_ITEMS.find((m) => m.name.toLowerCase().includes(pairing.dishName.toLowerCase().slice(0, 8))) || {
      id: `dish-pair-${pairing.id}`,
      name: pairing.dishName,
      category: 'breakfast',
      description: pairing.description,
      price: pairing.price * 0.6,
      image: pairing.dishImage,
    };

    const drink = MENU_ITEMS.find((m) => m.name.toLowerCase().includes(pairing.drinkName.toLowerCase().slice(0, 8))) || {
      id: `drink-pair-${pairing.id}`,
      name: pairing.drinkName,
      category: 'coffee',
      description: pairing.description,
      price: pairing.price * 0.4,
      image: pairing.drinkImage,
    };

    onAddPairingToCart(dish as MenuItem, drink as MenuItem, pairing.bundlePrice);
    setAddedPairingNotice(pairing.id);
    setTimeout(() => setAddedPairingNotice(null), 2500);
  };

  return (
    <section id="suggest" className="py-16 bg-[#f3ede2] border-t border-[#e2d5c3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Part 1: Barista's Mood-Based Food & Drink Pairing Recommender */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0] inline-flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#94552b]" />
              Smart Pairing Engine
            </span>
            <h2 className="font-serif-title text-3xl sm:text-4xl font-bold text-[#271b12] tracking-tight">
              What&apos;s Your Vibe Today?
            </h2>
            <p className="text-sm sm:text-base text-[#695445]">
              Select your current mood or craving, and let our head roaster & chef suggest the ideal harmonious dish + drink duo.
            </p>
          </div>

          {/* Mood Selector Tabs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            {MOOD_PAIRINGS.map((p) => {
              const isSelected = activeMoodId === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setActiveMoodId(p.id)}
                  className={`p-4 rounded-2xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-[#4a3528] text-white border-[#4a3528] shadow-md shadow-[#4a3528]/20 scale-102'
                      : 'bg-[#faf7f2] hover:bg-white text-[#5c4738] border-[#dfceb9]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                      isSelected ? 'bg-[#70523d] text-[#e8c6a5]' : 'bg-[#eadecf] text-[#71543d]'
                    }`}>
                      {p.badge}
                    </span>
                    {p.id === 'p1' && <Zap className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-amber-600'}`} />}
                    {p.id === 'p2' && <Heart className={`w-4 h-4 ${isSelected ? 'text-rose-300' : 'text-rose-500'}`} />}
                    {p.id === 'p3' && <Leaf className={`w-4 h-4 ${isSelected ? 'text-emerald-300' : 'text-emerald-600'}`} />}
                    {p.id === 'p4' && <Coffee className={`w-4 h-4 ${isSelected ? 'text-orange-300' : 'text-orange-600'}`} />}
                  </div>
                  <div className="font-serif-title font-bold text-sm sm:text-base leading-snug">
                    {p.mood}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Featured Pairing Card Showcase */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#e5d8c6] shadow-xl">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Dual Visuals */}
              <div className="lg:col-span-6 grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="relative rounded-2xl overflow-hidden aspect-square border border-[#dfd0bd] shadow-sm">
                    <img
                      src={selectedPairing.dishImage}
                      alt={selectedPairing.dishName}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 left-2 text-[10px] font-bold uppercase px-2 py-0.5 bg-black/60 text-white rounded backdrop-blur-xs">
                      Main Dish
                    </span>
                  </div>
                  <div className="text-xs font-serif-title font-bold text-[#2a1c13] truncate">
                    {selectedPairing.dishName}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="relative rounded-2xl overflow-hidden aspect-square border border-[#dfd0bd] shadow-sm">
                    <img
                      src={selectedPairing.drinkImage}
                      alt={selectedPairing.drinkName}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 left-2 text-[10px] font-bold uppercase px-2 py-0.5 bg-black/60 text-white rounded backdrop-blur-xs">
                      Harmonious Drink
                    </span>
                  </div>
                  <div className="text-xs font-serif-title font-bold text-[#2a1c13] truncate">
                    {selectedPairing.drinkName}
                  </div>
                </div>
              </div>

              {/* Pairing Details & Order */}
              <div className="lg:col-span-6 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#e8dac7] text-[#844c25] border border-[#d6beaa]">
                    Curated Pairing Bundle
                  </span>
                  <div className="flex gap-1">
                    {selectedPairing.tags.map((t) => (
                      <span key={t} className="text-[10px] bg-[#f4ece0] text-[#715743] px-2 py-0.5 rounded">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <h3 className="font-serif-title text-2xl font-bold text-[#271b12]">
                  {selectedPairing.dishName} & {selectedPairing.drinkName}
                </h3>

                <p className="text-sm text-[#665040] leading-relaxed">
                  {selectedPairing.description}
                </p>

                {/* Bundle Price Banner */}
                <div className="bg-[#fbf7f2] border border-[#e2d5c3] p-4 rounded-2xl flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-[#866a55] block">Combo Bundle Discount</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-serif-title font-bold text-[#884e27]">
                        ${selectedPairing.bundlePrice.toFixed(2)}
                      </span>
                      <span className="text-sm text-[#9f8572] line-through">
                        ${selectedPairing.price.toFixed(2)}
                      </span>
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                        Save ${(selectedPairing.price - selectedPairing.bundlePrice).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleOrderPairing(selectedPairing)}
                    className="bg-[#4a3528] hover:bg-[#34241b] active:scale-95 text-[#fbf7f2] text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                  >
                    <span>Order Both</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#e2b77c]" />
                  </button>
                </div>

                {addedPairingNotice === selectedPairing.id && (
                  <p className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Both items added to your order bag with bundle discount!
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Part 2: Community Suggestion Box */}
        <div className="pt-6 border-t border-[#dfd0bd]">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Left: Explain & Submit Form (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0] inline-flex items-center gap-1.5">
                  <MessageSquarePlus className="w-3.5 h-3.5 text-[#94552b]" />
                  Patron Suggestion Box
                </span>
                <h3 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#271b12]">
                  Have an Idea for Our Next Special?
                </h3>
                <p className="text-xs sm:text-sm text-[#665243] leading-relaxed">
                  We believe our cafe belongs to the neighborhood. Tell us what drink infusions, bakery treats, or events you want to experience next. Our head chef reviews the top voted ideas every Tuesday!
                </p>
              </div>

              <form onSubmit={handleSubmitSuggestion} className="bg-white p-5 rounded-2xl border border-[#dfd0bd] shadow-sm space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#73513a]">
                  Drop a Suggestion
                </h4>

                <div>
                  <label className="text-[11px] font-medium text-[#6e5849] block mb-1">
                    Suggestion Title
                  </label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Cardamom Honeycomb Cold Brew"
                    className="w-full bg-[#fbf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-medium text-[#6e5849] block mb-1">
                      Category
                    </label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full bg-[#fbf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-2 text-xs text-[#271b12] focus:outline-none"
                    >
                      <option>Drink Creation</option>
                      <option>Bakery</option>
                      <option>Brunch Dish</option>
                      <option>Events & Vibe</option>
                      <option>Roastery Sourcing</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-[#6e5849] block mb-1">
                      Your Name / Handle
                    </label>
                    <input
                      type="text"
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      placeholder="e.g. Alex M."
                      className="w-full bg-[#fbf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-[#6e5849] block mb-1">
                    Description & Why You Love It
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Describe the flavors, texture, or occasion..."
                    className="w-full bg-[#fbf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#884e27] hover:bg-[#723f1e] active:scale-98 text-white text-xs font-semibold py-2.5 rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit to Suggestion Wall</span>
                </button>

                {showSubmitSuccess && (
                  <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-800 text-[11px] text-center font-medium">
                    Thank you! Your idea is posted on the suggestion board below.
                  </div>
                )}
              </form>
            </div>

            {/* Right: Live Community Suggestion Wall (7 cols) */}
            <div className="lg:col-span-7 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-serif-title font-bold text-lg text-[#271b12]">
                  Trending Community Suggestions
                </h4>
                <span className="text-xs text-[#7d6554]">
                  Upvote your favorites to see them on our menu!
                </span>
              </div>

              <div className="space-y-3">
                {communitySuggestions.map((sug) => (
                  <div
                    key={sug.id}
                    className="bg-white p-4 sm:p-5 rounded-2xl border border-[#e5d8c6] shadow-xs flex items-start gap-4 transition-all hover:border-[#cfbba4]"
                  >
                    {/* Upvote Button */}
                    <button
                      onClick={() => handleUpvote(sug.id)}
                      className={`flex flex-col items-center justify-center p-2.5 rounded-xl min-w-[50px] transition-all cursor-pointer ${
                        sug.hasUpvoted
                          ? 'bg-[#884e27] text-white shadow-xs'
                          : 'bg-[#f4ece0] text-[#6d513d] hover:bg-[#ebdccb]'
                      }`}
                    >
                      <ThumbsUp className="w-4 h-4 mb-1" />
                      <span className="text-xs font-bold">{sug.upvotes}</span>
                    </button>

                    {/* Content */}
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <h5 className="font-serif-title font-bold text-base text-[#271b12]">
                          {sug.title}
                        </h5>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          sug.status === 'Barista Testing'
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : sug.status === 'Coming Next Season'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {sug.status}
                        </span>
                      </div>

                      <p className="text-xs text-[#634e3f] leading-relaxed">
                        {sug.description}
                      </p>

                      <div className="flex items-center gap-3 pt-2 text-[11px] text-[#8e7360]">
                        <span className="font-medium text-[#4a3528]">By {sug.author}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Tag className="w-3 h-3 text-[#a88267]" /> {sug.category}
                        </span>
                        <span>•</span>
                        <span>{sug.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
