import React, { useState } from 'react';
import {
  Search,
  Filter,
  Plus,
  Flame,
  Check,
  Sparkles,
  Coffee,
  Croissant,
  Soup,
  Clock,
  Heart,
  Eye,
  X
} from 'lucide-react';
import { MenuItem, Category } from '../types';
import { MENU_ITEMS } from '../data/cafeData';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem, customization?: { size?: 'Regular' | 'Large' | 'Extra Large'; milk?: string; notes?: string }) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietaryFilter, setDietaryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItemForModal, setSelectedItemForModal] = useState<MenuItem | null>(null);

  // Modal customizer states
  const [modalSize, setModalSize] = useState<'Regular' | 'Large' | 'Extra Large'>('Regular');
  const [modalMilk, setModalMilk] = useState<string>('Whole Milk');
  const [modalNotes, setModalNotes] = useState<string>('');
  const [addedNoticeId, setAddedNoticeId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'Full Menu', icon: Sparkles },
    { id: 'coffee', label: 'Coffee & Espresso', icon: Coffee },
    { id: 'tea', label: 'Teas & Cold Drinks', icon: Flame },
    { id: 'bakery', label: 'Bakery & Pastries', icon: Croissant },
    { id: 'breakfast', label: 'Breakfast & Brunch', icon: Heart },
    { id: 'lunch', label: 'Lunch & Savory', icon: Soup },
  ];

  const filteredItems = MENU_ITEMS.filter((item) => {
    // Category match
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }
    // Dietary match
    if (dietaryFilter !== 'all') {
      if (!item.dietary || !item.dietary.includes(dietaryFilter as any)) {
        return false;
      }
    }
    // Search match
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchCat) return false;
    }
    return true;
  });

  const handleQuickAdd = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    onAddToCart(item);
    setAddedNoticeId(item.id);
    setTimeout(() => setAddedNoticeId(null), 1800);
  };

  const handleModalAdd = () => {
    if (!selectedItemForModal) return;
    onAddToCart(selectedItemForModal, {
      size: modalSize,
      milk: modalMilk,
      notes: modalNotes.trim() || undefined,
    });
    setAddedNoticeId(selectedItemForModal.id);
    setSelectedItemForModal(null);
    setTimeout(() => setAddedNoticeId(null), 1800);
  };

  return (
    <section id="menu" className="py-16 bg-[#faf7f2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0]">
            Artisan Kitchen & Barista Counter
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl font-bold text-[#271b12] tracking-tight">
            Our Handcrafted Menu
          </h2>
          <p className="text-sm sm:text-base text-[#695445] leading-relaxed">
            Prepared fresh to order using organic, locally farmed produce, house-milled grains, and ethical single-origin coffee.
          </p>
        </div>

        {/* Search & Filters Control Bar */}
        <div className="bg-[#f2e9dc] p-4 sm:p-5 rounded-3xl border border-[#e2d5c3] shadow-xs mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full md:max-w-md">
              <Search className="w-4 h-4 text-[#8a6b52] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search cortado, shakshuka, croissant, matcha..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/90 border border-[#d6c4ae] text-sm text-[#271b12] placeholder-[#8a7260] focus:outline-none focus:ring-2 focus:ring-[#8e5229]/40"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#8a7260] hover:text-[#271b12]"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Dietary Pills */}
            <div className="flex items-center gap-1.5 flex-wrap w-full md:w-auto">
              <span className="text-xs font-semibold text-[#6d5543] flex items-center gap-1 mr-1">
                <Filter className="w-3.5 h-3.5" /> Dietary:
              </span>
              {[
                { id: 'all', label: 'All' },
                { id: 'vegetarian', label: 'Vegetarian' },
                { id: 'vegan', label: 'Vegan' },
                { id: 'gluten-free', label: 'Gluten-Free' },
              ].map((diet) => (
                <button
                  key={diet.id}
                  onClick={() => setDietaryFilter(diet.id)}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                    dietaryFilter === diet.id
                      ? 'bg-[#4a3528] text-white shadow-xs'
                      : 'bg-[#e4d6c4] text-[#5c4738] hover:bg-[#d8c7b3]'
                  }`}
                >
                  {diet.label}
                </button>
              ))}
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#894f28] text-white shadow-sm shadow-[#894f28]/25'
                      : 'bg-white/80 hover:bg-white text-[#5c4433] border border-[#d8c7b2]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#f2e9dc]/60 rounded-3xl border border-[#e2d5c3]">
            <Coffee className="w-10 h-10 text-[#a3836c] mx-auto mb-3 opacity-60" />
            <h3 className="font-serif-title text-lg font-bold text-[#2d1e15]">No menu items found</h3>
            <p className="text-xs text-[#715c4d] mt-1">Try clearing your search query or dietary filters.</p>
            <button
              onClick={() => { setSearchQuery(''); setDietaryFilter('all'); setSelectedCategory('all'); }}
              className="mt-4 text-xs font-semibold text-[#8b4f26] bg-[#ebdccb] px-4 py-2 rounded-xl border border-[#d3beaa]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => {
              const isAdded = addedNoticeId === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedItemForModal(item)}
                  className="group bg-white rounded-3xl overflow-hidden border border-[#e6dbc9] hover:border-[#cfbca5] transition-all duration-300 hover:shadow-xl hover:shadow-[#4a3528]/8 flex flex-col justify-between cursor-pointer"
                >
                  {/* Top Image Banner */}
                  <div className="relative aspect-16/10 overflow-hidden bg-[#e8decf]">
                    <img
                      src={item.image}
                      alt={item.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                      {item.popular && (
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#884e27] text-white px-2 py-0.5 rounded-full shadow-xs">
                          Chef Pick
                        </span>
                      )}
                      {item.isSpecialty && (
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#2e1d14] text-[#e8c39e] px-2 py-0.5 rounded-full shadow-xs">
                          Single Origin
                        </span>
                      )}
                    </div>

                    {/* Quick view prompt */}
                    <span className="absolute bottom-3 right-3 text-[11px] font-medium bg-black/60 backdrop-blur-xs text-white px-2.5 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      <Eye className="w-3 h-3" /> Quick Details
                    </span>
                  </div>

                  {/* Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-baseline justify-between gap-2 mb-1.5">
                        <h3 className="font-serif-title font-bold text-lg text-[#271b12] group-hover:text-[#884e27] transition-colors leading-snug">
                          {item.name}
                        </h3>
                        <span className="font-serif-title font-bold text-lg text-[#884e27] shrink-0">
                          ${item.price.toFixed(2)}
                        </span>
                      </div>

                      <p className="text-xs text-[#6e5849] leading-relaxed line-clamp-2 mb-3">
                        {item.description}
                      </p>
                    </div>

                    {/* Dietary Tags & Action Button */}
                    <div className="pt-3 border-t border-[#f0e8dc] flex items-center justify-between gap-2">
                      <div className="flex flex-wrap gap-1">
                        {item.dietary?.map((tag) => (
                          <span
                            key={tag}
                            className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-[#f2e9dc] text-[#5e4738] capitalize"
                          >
                            {tag}
                          </span>
                        ))}
                        {item.prepTime && (
                          <span className="text-[10px] text-[#937b6a] flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {item.prepTime}
                          </span>
                        )}
                      </div>

                      <button
                        onClick={(e) => handleQuickAdd(e, item)}
                        className={`text-xs font-semibold py-1.5 px-3 rounded-xl transition-all flex items-center gap-1 shrink-0 cursor-pointer ${
                          isAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#4a3528] hover:bg-[#34241b] text-white shadow-xs'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added!</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Item Detail & Customization Modal */}
      {selectedItemForModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#faf7f2] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#dfceb9] animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Image Header */}
            <div className="relative aspect-16/9 bg-[#e0d3c1]">
              <img
                src={selectedItemForModal.image}
                alt={selectedItemForModal.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedItemForModal(null)}
                className="absolute top-3 right-3 bg-black/60 hover:bg-black text-white p-1.5 rounded-full backdrop-blur-xs cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-serif-title font-bold text-2xl text-[#271b12]">
                    {selectedItemForModal.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-[#84522f] font-semibold uppercase tracking-wider">
                      {selectedItemForModal.category}
                    </span>
                    {selectedItemForModal.calories && (
                      <span className="text-xs text-[#7d6755]">• {selectedItemForModal.calories} kcal</span>
                    )}
                  </div>
                </div>
                <div className="text-2xl font-serif-title font-bold text-[#884e27]">
                  ${selectedItemForModal.price.toFixed(2)}
                </div>
              </div>

              <p className="text-sm text-[#5f493b] leading-relaxed">
                {selectedItemForModal.description}
              </p>

              {/* Options if Drink */}
              {(selectedItemForModal.category === 'coffee' || selectedItemForModal.category === 'tea') && (
                <div className="space-y-3 pt-3 border-t border-[#e8decb]">
                  {/* Size */}
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-[#75553e] block mb-1.5">
                      Cup Size
                    </label>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {(['Regular', 'Large', 'Extra Large'] as const).map((sz) => (
                        <button
                          key={sz}
                          onClick={() => setModalSize(sz)}
                          className={`py-2 px-3 rounded-xl border text-center transition-all cursor-pointer font-medium ${
                            modalSize === sz
                              ? 'bg-[#4a3528] text-white border-[#4a3528]'
                              : 'bg-white border-[#d8c5b0] text-[#553f31]'
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Milk Option */}
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-[#75553e] block mb-1.5">
                      Milk Preference
                    </label>
                    <select
                      value={modalMilk}
                      onChange={(e) => setModalMilk(e.target.value)}
                      className="w-full bg-white border border-[#d8c5b0] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none"
                    >
                      <option>Whole Grass-Fed Milk</option>
                      <option>Oatly Barista Edition (+ $0.75)</option>
                      <option>Almond Milk (+ $0.75)</option>
                      <option>Coconut Cream (+ $0.85)</option>
                      <option>No Milk (Black)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Special Instructions */}
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#75553e] block mb-1.5">
                  Special Kitchen Note (Allergies, extra warm, dressing on side)
                </label>
                <input
                  type="text"
                  value={modalNotes}
                  onChange={(e) => setModalNotes(e.target.value)}
                  placeholder="e.g. Extra hot, decaf, oat milk, no cilantro..."
                  className="w-full bg-white border border-[#d8c5b0] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                />
              </div>

              {/* Footer action */}
              <div className="pt-4 flex gap-3">
                <button
                  onClick={() => setSelectedItemForModal(null)}
                  className="w-1/3 py-3 rounded-xl text-xs font-semibold text-[#664d3b] bg-[#ede1d2] hover:bg-[#dfd0bd] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleModalAdd}
                  className="w-2/3 py-3 rounded-xl text-xs font-semibold text-white bg-[#884e27] hover:bg-[#723f1e] shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add to Order Bag (${selectedItemForModal.price.toFixed(2)})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
