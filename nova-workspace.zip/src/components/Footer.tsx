import React from 'react';
import {
  Coffee,
  Heart,
  MapPin,
  Phone,
  Mail,
  Instagram,
  Clock,
  Code
} from 'lucide-react';
import { CAFE_INFO } from '../data/cafeData';

interface FooterProps {
  onNavClick: (section: string) => void;
  onOpenEmbedModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavClick, onOpenEmbedModal }) => {
  return (
    <footer className="bg-[#241710] text-[#e8dacb] border-t border-[#442c1e] pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#884e27] text-white flex items-center justify-center shadow-lg">
                <Coffee className="w-5 h-5 text-[#f5dbbe]" />
              </div>
              <div>
                <span className="font-serif-title font-bold text-xl text-white block">
                  Velvet Roast
                </span>
                <span className="text-[10px] uppercase tracking-wider text-[#d8a474] font-semibold">
                  Cafe & Bakehouse
                </span>
              </div>
            </div>

            <p className="text-xs text-[#b89f8d] leading-relaxed">
              Small-batch roastery, 36-hour wild fermented sourdough bakes, and farm-to-table brunch in the heart of Elmwood.
            </p>

            <button
              onClick={onOpenEmbedModal}
              className="inline-flex items-center gap-1.5 text-xs text-[#d8a474] hover:text-white bg-[#3b271b] border border-[#5d3f2b] px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Code className="w-3.5 h-3.5" />
              <span>Google Sites Embed Code</span>
            </button>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#d8a474]">
              Explore
            </h4>
            <ul className="space-y-2 text-xs text-[#c4ad9b]">
              <li>
                <button onClick={() => onNavClick('menu')} className="hover:text-white cursor-pointer">
                  Handcrafted Menu & Pastries
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('special')} className="hover:text-white cursor-pointer text-[#e0ab77] font-semibold">
                  Custom Brew Lab (Special Feature ✨)
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('suggest')} className="hover:text-white cursor-pointer">
                  Mood & Craving Pairings
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('suggest')} className="hover:text-white cursor-pointer">
                  Patron Suggestion Box
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('about')} className="hover:text-white cursor-pointer">
                  Our Roasting Philosophy
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick('reviews')} className="hover:text-white cursor-pointer">
                  Verified Guest Reviews
                </button>
              </li>
            </ul>
          </div>

          {/* Hours & Schedule */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#d8a474]">
              Cafe Hours
            </h4>
            <ul className="space-y-1.5 text-xs text-[#c4ad9b]">
              <li className="flex justify-between">
                <span>Mon – Fri:</span>
                <span className="font-semibold text-white">6:30 AM – 7 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Saturday:</span>
                <span className="font-semibold text-white">7:00 AM – 8 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Sunday:</span>
                <span className="font-semibold text-white">7:30 AM – 6 PM</span>
              </li>
              <li className="pt-1 text-[11px] text-[#9a7e6c]">
                Kitchen brunch closes daily at 3:30 PM. Coffee & bakery available all day.
              </li>
            </ul>
          </div>

          {/* Location & Contact */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#d8a474]">
              Contact & Location
            </h4>
            <div className="space-y-2 text-xs text-[#c4ad9b]">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#d8a474] shrink-0 mt-0.5" />
                <span>{CAFE_INFO.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#d8a474] shrink-0" />
                <span>{CAFE_INFO.phone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#d8a474] shrink-0" />
                <span>{CAFE_INFO.email}</span>
              </p>
              <p className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-[#d8a474] shrink-0" />
                <span>{CAFE_INFO.instagram}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Sub-footer */}
        <div className="pt-6 border-t border-[#3e271a] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#8c7463]">
          <p>© {new Date().getFullYear()} Velvet Roast Cafe & Bakehouse. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Free Gigabit Wi-Fi</span>
            <span>•</span>
            <span>Dog-Friendly Patio</span>
            <span>•</span>
            <span>Embed-Ready for Google Sites</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
