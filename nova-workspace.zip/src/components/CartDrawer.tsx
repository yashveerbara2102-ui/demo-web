import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  Clock,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Coffee
} from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartId: string, delta: number) => void;
  onRemoveItem: (cartId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}) => {
  const [tipPercent, setTipPercent] = useState<number>(18);
  const [diningOption, setDiningOption] = useState<'pickup' | 'dine-in'>('pickup');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => sum + item.itemTotal, 0);
  const tax = Number((subtotal * 0.0825).toFixed(2));
  const tipAmount = Number(((subtotal * tipPercent) / 100).toFixed(2));
  const grandTotal = Number((subtotal + tax + tipAmount).toFixed(2));

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedOrderNum = `VR-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderNumber(generatedOrderNum);
    setOrderPlaced(true);
  };

  const handleStartNewOrder = () => {
    setOrderPlaced(false);
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-[#faf7f2] h-full flex flex-col shadow-2xl border-l border-[#dfceba] animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-5 border-b border-[#ebdccb] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#884e27]" />
            <h3 className="font-serif-title font-bold text-lg text-[#271b12]">
              Your Cafe Order Bag
            </h3>
            <span className="text-xs bg-[#ebdccb] text-[#5e4431] px-2 py-0.5 rounded-full font-bold">
              {cartItems.reduce((acc, i) => acc + i.quantity, 0)}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#ebdccb] text-[#5e4431] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        {orderPlaced ? (
          /* Order Confirmed Screen */
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-widest text-[#884e27]">
                Order Confirmed & Sent to Kitchen
              </span>
              <h4 className="font-serif-title text-2xl font-bold text-[#271b12]">
                Order #{orderNumber}
              </h4>
              <p className="text-xs text-[#6e5849]">
                Estimated preparation time: <strong>12 – 15 minutes</strong>
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-[#dfceba] w-full text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-[#88705f]">Customer:</span>
                <span className="font-bold text-[#2a1c13]">{customerName || 'Valued Guest'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#88705f]">Format:</span>
                <span className="font-bold text-[#2a1c13] capitalize">{diningOption} Order</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#88705f]">Total Paid:</span>
                <span className="font-bold text-[#884e27]">${grandTotal.toFixed(2)}</span>
              </div>
              <div className="pt-2 border-t border-[#f2e9dc] text-[11px] text-[#745f50]">
                Show order #{orderNumber} to our Elmwood barista counter when you arrive.
              </div>
            </div>

            <button
              onClick={handleStartNewOrder}
              className="w-full bg-[#4a3528] hover:bg-[#34241b] text-white font-semibold py-3 px-4 rounded-xl text-xs transition-colors cursor-pointer"
            >
              Start Another Order
            </button>
          </div>
        ) : cartItems.length === 0 ? (
          /* Empty Bag State */
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#ebdccb] text-[#884e27] flex items-center justify-center">
              <Coffee className="w-7 h-7" />
            </div>
            <h4 className="font-serif-title font-bold text-lg text-[#271b12]">
              Your order bag is empty
            </h4>
            <p className="text-xs text-[#715c4d] max-w-xs">
              Explore our handcrafted coffee, fresh sourdough bakes, or try the Custom Brew Lab!
            </p>
            <button
              onClick={onClose}
              className="mt-2 text-xs font-semibold text-white bg-[#884e27] hover:bg-[#723f1e] px-4 py-2 rounded-xl transition-all cursor-pointer"
            >
              Browse Cafe Menu
            </button>
          </div>
        ) : (
          /* Cart Item List & Form */
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {/* Pickup Notice */}
              <div className="bg-[#f0e6d8] p-3 rounded-2xl flex items-center gap-2.5 text-xs text-[#594232]">
                <Clock className="w-4 h-4 text-[#884e27] shrink-0" />
                <span>Express Counter Pickup: Ready in <strong>~12 mins</strong></span>
              </div>

              {/* Items */}
              {cartItems.map((item) => (
                <div
                  key={item.cartId}
                  className="bg-white p-3.5 rounded-2xl border border-[#ebdccb] shadow-xs space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h5 className="font-serif-title font-bold text-sm text-[#271b12]">
                        {item.menuItem.name}
                      </h5>
                      <div className="text-[11px] text-[#866e5d] space-x-1">
                        {item.size && <span>Size: {item.size} •</span>}
                        {item.milk && <span>{item.milk}</span>}
                      </div>
                      {item.notes && (
                        <p className="text-[10px] text-[#937b6a] italic mt-0.5 line-clamp-1">
                          Note: {item.notes}
                        </p>
                      )}
                    </div>
                    <span className="font-serif-title font-bold text-sm text-[#884e27]">
                      ${item.itemTotal.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#f4ece0]">
                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 bg-[#f4ece0] rounded-lg p-1">
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, -1)}
                        className="w-6 h-6 rounded bg-white hover:bg-slate-50 flex items-center justify-center text-[#4a3528] cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold px-1.5">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, 1)}
                        className="w-6 h-6 rounded bg-white hover:bg-slate-50 flex items-center justify-center text-[#4a3528] cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.cartId)}
                      className="text-[#a48671] hover:text-rose-600 p-1 cursor-pointer transition-colors"
                      title="Remove Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Checkout Section */}
            <form onSubmit={handleCheckout} className="p-4 bg-white border-t border-[#ebdccb] space-y-3">
              {/* Order Type Toggle */}
              <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setDiningOption('pickup')}
                  className={`py-2 rounded-xl border text-center transition-all cursor-pointer ${
                    diningOption === 'pickup'
                      ? 'bg-[#4a3528] text-white border-[#4a3528]'
                      : 'bg-[#faf7f2] text-[#6d5543] border-[#ded0bd]'
                  }`}
                >
                  Takeaway Pickup
                </button>
                <button
                  type="button"
                  onClick={() => setDiningOption('dine-in')}
                  className={`py-2 rounded-xl border text-center transition-all cursor-pointer ${
                    diningOption === 'dine-in'
                      ? 'bg-[#4a3528] text-white border-[#4a3528]'
                      : 'bg-[#faf7f2] text-[#6d5543] border-[#ded0bd]'
                  }`}
                >
                  Dine-In Table
                </button>
              </div>

              {/* Guest Details */}
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Your Name"
                  className="bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-1.5 text-xs text-[#271b12] focus:outline-none"
                />
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="Phone (Optional for SMS)"
                  className="bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-1.5 text-xs text-[#271b12] focus:outline-none"
                />
              </div>

              {/* Tip Selection */}
              <div>
                <div className="flex justify-between text-[11px] font-bold text-[#715947] mb-1">
                  <span>Support Our Baristas (Tip)</span>
                  <span>${tipAmount.toFixed(2)}</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5 text-xs">
                  {[10, 15, 18, 20].map((t) => (
                    <button
                      type="button"
                      key={t}
                      onClick={() => setTipPercent(t)}
                      className={`py-1 rounded-lg border text-center transition-all cursor-pointer text-[11px] font-medium ${
                        tipPercent === t
                          ? 'bg-[#884e27] text-white border-[#884e27]'
                          : 'bg-[#faf7f2] text-[#634e3f] border-[#ded0bd]'
                      }`}
                    >
                      {t}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Totals Breakdown */}
              <div className="space-y-1 pt-2 border-t border-[#f4ece0] text-xs text-[#715c4d]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-[#271b12]">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Tax (8.25%)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tip</span>
                  <span>${tipAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-[#271b12] pt-1 border-t border-[#f2e9dc]">
                  <span>Total</span>
                  <span className="text-base text-[#884e27] font-serif-title">
                    ${grandTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Place Order CTA */}
              <button
                type="submit"
                className="w-full bg-[#884e27] hover:bg-[#723f1e] active:scale-98 text-white font-semibold py-3 px-4 rounded-xl text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Place Order (${grandTotal.toFixed(2)})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
