import React, { useState } from 'react';
import {
  Sparkles,
  Coffee,
  Flame,
  Droplets,
  Layers,
  Thermometer,
  Check,
  Plus,
  ShoppingBag,
  Share2,
  Sliders,
  Award
} from 'lucide-react';
import { MenuItem } from '../types';

interface SpecialFeatureBrewLabProps {
  onAddCustomDrinkToCart: (item: MenuItem, customizationNote: string) => void;
}

const BASES = [
  { id: 'espresso', name: 'Ethiopian Single-Origin Espresso', caffeine: '140mg', desc: 'Floral, jasmine & citrus notes', price: 4.50 },
  { id: 'kyoto', name: '18-Hour Kyoto Slow Cold Brew', caffeine: '190mg', desc: 'Dark chocolate, berry & smoky hazelnut', price: 5.25 },
  { id: 'matcha', name: 'Ceremonial Uji Japanese Matcha', caffeine: '80mg', desc: 'Rich umami, sweet vegetal & calm focus', price: 5.50 },
  { id: 'decaf', name: 'Swiss Water Process Decaf', caffeine: '<5mg', desc: 'Full-bodied caramelized sugar & pecan', price: 4.50 },
];

const MILKS = [
  { id: 'oat', name: 'Oatly Barista Creamy Oat', cal: '+90 cal', price: 0.75 },
  { id: 'whole', name: 'Local Grass-Fed Whole Milk', cal: '+110 cal', price: 0.00 },
  { id: 'almond', name: 'House Almond Cashew Blend', cal: '+60 cal', price: 0.75 },
  { id: 'coconut', name: 'Organic Coconut Cream', cal: '+100 cal', price: 0.85 },
  { id: 'none', name: 'Black / Pure (No Milk)', cal: '0 cal', price: 0.00 },
];

const TEMPS = [
  { id: 'hot', label: 'Silky Hot (145°F)', icon: '🔥' },
  { id: 'iced', label: 'Crystal Ice Cubes', icon: '🧊' },
  { id: 'nitro', label: 'Nitro Cold Draft (Smooth Tap)', icon: '✨' },
];

const SWEETNESS_LEVELS = ['Unsweetened (0%)', 'Subtle Touch (25%)', 'Balanced (50%)', 'Full Sweet (100%)'];

const INFUSIONS = [
  { id: 'honeycomb', name: 'House Honeycomb Candy Crumbs', price: 0.80 },
  { id: 'cardamom', name: 'Spiced Green Cardamom Pods', price: 0.60 },
  { id: 'vanilla', name: 'Madagascar Bourbon Vanilla Bean', price: 0.75 },
  { id: 'caramel', name: 'Smoked Salted Butter Caramel', price: 0.80 },
  { id: 'lavender', name: 'French Culinary Lavender Mist', price: 0.65 },
];

const TOPPINGS = [
  'Cinnamon Dusting',
  'Maldon Flaky Sea Salt',
  'Roasted Cacao Nibs',
  'Vanilla Cold Foam (+ $1.00)',
  'None'
];

export const SpecialFeatureBrewLab: React.FC<SpecialFeatureBrewLabProps> = ({
  onAddCustomDrinkToCart,
}) => {
  const [selectedBase, setSelectedBase] = useState(BASES[0]);
  const [selectedMilk, setSelectedMilk] = useState(MILKS[0]);
  const [selectedTemp, setSelectedTemp] = useState(TEMPS[1]);
  const [selectedSweetness, setSelectedSweetness] = useState('Subtle Touch (25%)');
  const [selectedInfusions, setSelectedInfusions] = useState<string[]>(['honeycomb']);
  const [selectedTopping, setSelectedTopping] = useState('Maldon Flaky Sea Salt');
  const [customDrinkName, setCustomDrinkName] = useState('My Signature Velvet Brew');
  const [copiedCode, setCopiedCode] = useState(false);
  const [addedNotice, setAddedNotice] = useState(false);

  const toggleInfusion = (id: string) => {
    if (selectedInfusions.includes(id)) {
      setSelectedInfusions(selectedInfusions.filter(item => item !== id));
    } else {
      if (selectedInfusions.length >= 2) {
        setSelectedInfusions([selectedInfusions[1], id]);
      } else {
        setSelectedInfusions([...selectedInfusions, id]);
      }
    }
  };

  // Calculate dynamic price
  const basePrice = selectedBase.price + selectedMilk.price;
  const infusionsPrice = selectedInfusions.reduce((sum, infId) => {
    const inf = INFUSIONS.find(i => i.id === infId);
    return sum + (inf ? inf.price : 0);
  }, 0);
  const toppingPrice = selectedTopping.includes('$1.00') ? 1.00 : 0.00;
  const totalPrice = Number((basePrice + infusionsPrice + toppingPrice).toFixed(2));

  // Generated dynamic recipe code
  const recipeCode = `VR-LAB-${selectedBase.id.toUpperCase().slice(0, 3)}-${selectedMilk.id.toUpperCase().slice(0, 3)}-${selectedTemp.id.toUpperCase()}`;

  const handleOrderCustomDrink = () => {
    const customItem: MenuItem = {
      id: `custom-brew-${Date.now()}`,
      name: customDrinkName.trim() || 'Custom Lab Signature Brew',
      category: 'coffee',
      description: `${selectedTemp.label} with ${selectedBase.name}, ${selectedMilk.name}, ${selectedSweetness}. Infusions: ${selectedInfusions.length > 0 ? selectedInfusions.join(', ') : 'None'}. Topping: ${selectedTopping}.`,
      price: totalPrice,
      image: selectedBase.id === 'matcha'
        ? 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=600&q=80'
        : selectedTemp.id === 'hot'
        ? 'https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=600&q=80'
        : 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=600&q=80',
      popular: true,
      isSpecialty: true
    };

    const notes = `Recipe Code: ${recipeCode} | Base: ${selectedBase.name} | Milk: ${selectedMilk.name} | Sweet: ${selectedSweetness} | Infusions: ${selectedInfusions.join(', ')} | Topping: ${selectedTopping}`;

    onAddCustomDrinkToCart(customItem, notes);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 3000);
  };

  const handleCopyRecipe = () => {
    navigator.clipboard.writeText(`My Velvet Roast Recipe [${recipeCode}]: ${selectedBase.name} + ${selectedMilk.name} + ${selectedTemp.label} with ${selectedSweetness} & ${selectedTopping}`);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  return (
    <section id="special" className="py-16 bg-[#261912] text-[#f7efe6] relative overflow-hidden">
      {/* Decorative roastery elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#8a4e28]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#4a2e1d]/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header Badge & Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#4a3020] text-[#e5b382] border border-[#6b452e]">
            <Award className="w-3.5 h-3.5 text-[#e5b382]" />
            <span>Signature Feature</span>
            <span className="text-[#885a3c]">•</span>
            <span>Interactive Barista Experience</span>
          </div>

          <h2 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
            The Velvet Custom Brew Lab
          </h2>

          <p className="text-sm sm:text-base text-[#c9b19e] max-w-2xl mx-auto leading-relaxed">
            Every palate is unique. Select your single-origin extraction, milk consistency, infusion aromatics, and craft your signature beverage live. Order it to the counter or save your custom recipe code!
          </p>
        </div>

        {/* The Interactive Lab Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Configuration Steps (7 cols) */}
          <div className="lg:col-span-7 space-y-7 bg-[#342218]/90 border border-[#523726] p-6 sm:p-8 rounded-3xl backdrop-blur-md shadow-2xl">
            {/* Step 1: Base Extraction */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold uppercase tracking-wider text-[#dcb187] flex items-center gap-1.5">
                  <Coffee className="w-4 h-4" />
                  1. Choose Extraction Base
                </label>
                <span className="text-xs text-[#a98f7c]">Caffeine: {selectedBase.caffeine}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {BASES.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setSelectedBase(b)}
                    className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                      selectedBase.id === b.id
                        ? 'bg-[#5a3924] border-[#d8a474] text-white shadow-md'
                        : 'bg-[#2b1c13] border-[#442c1d] text-[#cfb7a5] hover:border-[#684630]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">{b.name}</span>
                      <span className="text-xs text-[#e0ab77] font-semibold">${b.price.toFixed(2)}</span>
                    </div>
                    <p className="text-[11px] text-[#a48e7f] mt-1 leading-tight">{b.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Milk & Plant Alternative */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#dcb187] flex items-center gap-1.5 mb-3">
                <Droplets className="w-4 h-4" />
                2. Select Milk or Plant Base
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {MILKS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMilk(m)}
                    className={`p-2.5 rounded-xl text-left border transition-all text-xs cursor-pointer ${
                      selectedMilk.id === m.id
                        ? 'bg-[#5a3924] border-[#d8a474] text-white font-semibold'
                        : 'bg-[#2b1c13] border-[#442c1d] text-[#cfb7a5] hover:border-[#684630]'
                    }`}
                  >
                    <div>{m.name}</div>
                    <div className="text-[10px] text-[#a88d7a] mt-0.5">
                      {m.cal} {m.price > 0 && `(+$${m.price.toFixed(2)})`}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Temperature & Draft */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#dcb187] flex items-center gap-1.5 mb-3">
                <Thermometer className="w-4 h-4" />
                3. Temperature & Texture
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {TEMPS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTemp(t)}
                    className={`p-3 rounded-xl text-center border transition-all text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                      selectedTemp.id === t.id
                        ? 'bg-[#5a3924] border-[#d8a474] text-white'
                        : 'bg-[#2b1c13] border-[#442c1d] text-[#cfb7a5] hover:border-[#684630]'
                    }`}
                  >
                    <span>{t.icon}</span>
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Sweetness & House Infusions */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold uppercase tracking-wider text-[#dcb187] flex items-center gap-1.5">
                  <Sliders className="w-4 h-4" />
                  4. Sweetness & Natural Infusions (Pick up to 2)
                </label>
                <span className="text-xs text-[#a98f7c]">
                  {selectedInfusions.length}/2 selected
                </span>
              </div>

              {/* Sweetness Slider / Selector */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-3">
                {SWEETNESS_LEVELS.map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setSelectedSweetness(lvl)}
                    className={`py-1.5 px-2 rounded-lg text-[11px] font-medium border text-center transition-all cursor-pointer ${
                      selectedSweetness === lvl
                        ? 'bg-[#d8a474] text-[#241710] font-bold border-[#d8a474]'
                        : 'bg-[#2b1c13] border-[#442c1d] text-[#c0a997]'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>

              {/* Infusions */}
              <div className="flex flex-wrap gap-2">
                {INFUSIONS.map((inf) => {
                  const active = selectedInfusions.includes(inf.id);
                  return (
                    <button
                      key={inf.id}
                      onClick={() => toggleInfusion(inf.id)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all flex items-center gap-1.5 cursor-pointer ${
                        active
                          ? 'bg-[#70462c] text-white border-[#d8a474]'
                          : 'bg-[#2b1c13] text-[#bca593] border-[#442c1d] hover:border-[#664632]'
                      }`}
                    >
                      {active ? <Check className="w-3 h-3 text-[#d8a474]" /> : <Plus className="w-3 h-3" />}
                      <span>{inf.name}</span>
                      <span className="text-[10px] text-[#e0ab77]">+${inf.price.toFixed(2)}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 5: Artisan Topping */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#dcb187] flex items-center gap-1.5 mb-2.5">
                <Layers className="w-4 h-4" />
                5. Hand-Dusted Garnish / Topping
              </label>
              <div className="flex flex-wrap gap-2">
                {TOPPINGS.map((top) => (
                  <button
                    key={top}
                    onClick={() => setSelectedTopping(top)}
                    className={`px-3 py-1.5 rounded-xl text-xs border transition-all cursor-pointer ${
                      selectedTopping === top
                        ? 'bg-[#5a3924] border-[#d8a474] text-white font-semibold'
                        : 'bg-[#2b1c13] border-[#442c1d] text-[#bda795]'
                    }`}
                  >
                    {top}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Live Drink Preview & Order Card (5 cols) */}
          <div className="lg:col-span-5 sticky top-24 space-y-4">
            <div className="bg-gradient-to-b from-[#3d271c] to-[#2b1a11] border-2 border-[#6d472f] rounded-3xl p-6 sm:p-7 shadow-2xl relative">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#d8a474] bg-[#533422] px-2.5 py-1 rounded-full border border-[#724a32]">
                  Live Recipe Card
                </span>
                <span className="text-xs font-mono text-[#aa917f] bg-[#1f130c] px-2.5 py-1 rounded-md">
                  {recipeCode}
                </span>
              </div>

              {/* Editable Name */}
              <div className="mb-4">
                <label className="text-[11px] text-[#bca593] block mb-1">Give your brew a name:</label>
                <input
                  type="text"
                  value={customDrinkName}
                  onChange={(e) => setCustomDrinkName(e.target.value)}
                  className="w-full bg-[#1e120c] border border-[#523726] rounded-xl px-3 py-2 text-sm text-white font-serif-title font-bold focus:outline-none focus:border-[#d8a474]"
                  placeholder="My Custom Drink Name"
                />
              </div>

              {/* Recipe Summary Breakdown */}
              <div className="space-y-2 py-3 border-y border-[#523726] text-xs">
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Extraction:</span>
                  <span className="font-semibold text-white">{selectedBase.name}</span>
                </div>
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Milk Base:</span>
                  <span className="font-semibold text-white">{selectedMilk.name}</span>
                </div>
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Temp & Format:</span>
                  <span className="font-semibold text-white">{selectedTemp.label}</span>
                </div>
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Sweetness:</span>
                  <span className="font-semibold text-white">{selectedSweetness}</span>
                </div>
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Infusions:</span>
                  <span className="font-semibold text-white">
                    {selectedInfusions.length > 0
                      ? selectedInfusions.map(id => INFUSIONS.find(i => i.id === id)?.name.split(' ')[0]).join(', ')
                      : 'None'}
                  </span>
                </div>
                <div className="flex justify-between text-[#d6c0af]">
                  <span>Topping:</span>
                  <span className="font-semibold text-white">{selectedTopping}</span>
                </div>
              </div>

              {/* Price & Action */}
              <div className="pt-4 flex items-baseline justify-between">
                <div>
                  <span className="text-[11px] text-[#a48e7f] block">Total Handcrafted Price</span>
                  <span className="text-3xl font-extrabold text-[#e5b382] font-serif-title">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
                <span className="text-xs text-[#a98f7c]">
                  Est. Calories: ~{120 + (selectedMilk.id === 'oat' ? 90 : selectedMilk.id === 'none' ? 0 : 100)} kcal
                </span>
              </div>

              {/* CTA Buttons */}
              <div className="mt-5 space-y-2.5">
                <button
                  onClick={handleOrderCustomDrink}
                  className="w-full flex items-center justify-center gap-2 bg-[#d8a474] hover:bg-[#e6b586] active:scale-95 text-[#241710] font-bold py-3.5 px-4 rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add Custom Brew to Order Bag</span>
                </button>

                <button
                  onClick={handleCopyRecipe}
                  className="w-full flex items-center justify-center gap-2 bg-[#42291c] hover:bg-[#523323] text-[#d6c0af] hover:text-white text-xs font-semibold py-2.5 px-4 rounded-xl border border-[#5d3b27] transition-colors cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Recipe Code Copied!' : 'Copy Recipe Card to Clipboard'}</span>
                </button>
              </div>

              {/* Toast Feedback */}
              {addedNotice && (
                <div className="mt-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-fadeIn">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Added to order bag! View in top right.</span>
                </div>
              )}
            </div>

            <div className="bg-[#2b1c13]/70 border border-[#442c1d] rounded-2xl p-4 text-xs text-[#b89f8d] flex items-center gap-3">
              <Sparkles className="w-4 h-4 text-[#d8a474] shrink-0" />
              <span>
                <strong>Barista Guarantee:</strong> If the custom flavor profile doesn&apos;t hit the spot, our baristas will happily re-pull your cup on the house.
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
