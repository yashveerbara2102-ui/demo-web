import React, { useState } from 'react';
import {
  Star,
  CheckCircle2,
  ThumbsUp,
  MessageSquare,
  PenTool,
  Heart,
  Coffee,
  X
} from 'lucide-react';
import { Review } from '../types';
import { REVIEWS_DATA } from '../data/cafeData';

export const ReviewsSection: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(REVIEWS_DATA);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [newAuthor, setNewAuthor] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newComment, setNewComment] = useState('');
  const [newFavoriteItem, setNewFavoriteItem] = useState('Velvet Signature Cortado');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    const newReview: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      avatar: `https://images.unsplash.com/photo-${1535713875002 + Math.floor(Math.random() * 1000)}?auto=format&fit=crop&w=150&q=80`,
      rating: newRating,
      date: 'Just now',
      title: newTitle.trim() || 'A delightful neighborhood cafe experience',
      comment: newComment.trim(),
      favoriteItem: newFavoriteItem,
      verified: true
    };

    setReviews([newReview, ...reviews]);
    setNewAuthor('');
    setNewTitle('');
    setNewComment('');
    setShowReviewModal(false);
    setSubmittedFeedback(true);
    setTimeout(() => setSubmittedFeedback(false), 4000);
  };

  return (
    <section id="reviews" className="py-16 bg-[#faf7f2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0] inline-flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-[#94552b]" />
            Neighborhood Love & Stories
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl font-bold text-[#271b12] tracking-tight">
            Guest Reviews & Experiences
          </h2>
          <p className="text-sm sm:text-base text-[#695445]">
            Read what local coffee enthusiasts, remote workers, and weekend brunch lovers have to say about Velvet Roast.
          </p>
        </div>

        {/* Rating Scorecard Banner */}
        <div className="bg-[#f3ece0] border border-[#e2d5c3] rounded-3xl p-6 sm:p-8 mb-10 shadow-xs">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            {/* Big Score (4 cols) */}
            <div className="md:col-span-4 text-center md:text-left space-y-2 md:border-r border-[#dfceba] md:pr-6">
              <div className="text-5xl font-extrabold text-[#2a1c13] font-serif-title">
                4.9 <span className="text-2xl text-[#8e6c54] font-normal">/ 5.0</span>
              </div>
              <div className="flex items-center justify-center md:justify-start gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                ))}
              </div>
              <p className="text-xs text-[#735a49]">
                Based on <strong>384+ verified dine-in & pickup ratings</strong>
              </p>
            </div>

            {/* Breakdown Bars (5 cols) */}
            <div className="md:col-span-5 space-y-1.5 text-xs text-[#5f4939]">
              <div className="flex items-center gap-2">
                <span className="w-12 font-medium">5 Stars</span>
                <div className="flex-1 bg-[#ded0bd] h-2 rounded-full overflow-hidden">
                  <div className="bg-[#884e27] h-full w-[92%]" />
                </div>
                <span className="w-8 text-right font-semibold">92%</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-12 font-medium">4 Stars</span>
                <div className="flex-1 bg-[#ded0bd] h-2 rounded-full overflow-hidden">
                  <div className="bg-[#884e27] h-full w-[6%]" />
                </div>
                <span className="w-8 text-right font-semibold">6%</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-12 font-medium">3 Stars</span>
                <div className="flex-1 bg-[#ded0bd] h-2 rounded-full overflow-hidden">
                  <div className="bg-[#884e27] h-full w-[1.5%]" />
                </div>
                <span className="w-8 text-right font-semibold">1.5%</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-12 font-medium">2 Stars</span>
                <div className="flex-1 bg-[#ded0bd] h-2 rounded-full overflow-hidden">
                  <div className="bg-[#884e27] h-full w-[0.5%]" />
                </div>
                <span className="w-8 text-right font-semibold">&lt;1%</span>
              </div>
            </div>

            {/* Action CTA (3 cols) */}
            <div className="md:col-span-3 text-center md:text-right">
              <button
                onClick={() => setShowReviewModal(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#4a3528] hover:bg-[#34241b] active:scale-95 text-white text-xs font-semibold px-4 py-3 rounded-xl transition-all shadow-sm cursor-pointer"
              >
                <PenTool className="w-3.5 h-3.5 text-[#e2b77c]" />
                <span>Write a Review</span>
              </button>
            </div>
          </div>
        </div>

        {/* Success Notice */}
        {submittedFeedback && (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Thank you for sharing your experience! Your review is now featured below.
          </div>
        )}

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-white p-6 rounded-3xl border border-[#e5d8c6] shadow-xs flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div>
                {/* Author Info & Star Rating */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={rev.avatar}
                      alt={rev.author}
                      className="w-10 h-10 rounded-full object-cover border border-[#e2d5c3]"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                    <div>
                      <div className="text-sm font-bold text-[#271b12] flex items-center gap-1.5">
                        <span>{rev.author}</span>
                        {rev.verified && (
                          <span title="Verified Patron" className="inline-flex items-center text-emerald-600">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-[#866f5f]">{rev.date}</span>
                    </div>
                  </div>

                  {/* Stars */}
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((st) => (
                      <Star
                        key={st}
                        className={`w-3.5 h-3.5 ${
                          st <= rev.rating ? 'fill-amber-500 text-amber-500' : 'text-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                <h4 className="font-serif-title font-bold text-base text-[#271b12] mb-1.5">
                  &ldquo;{rev.title}&rdquo;
                </h4>
                <p className="text-xs text-[#5c4738] leading-relaxed">
                  {rev.comment}
                </p>
              </div>

              {rev.favoriteItem && (
                <div className="mt-4 pt-3 border-t border-[#f2e9dc] flex items-center justify-between text-[11px] text-[#856b57]">
                  <span className="flex items-center gap-1">
                    <Coffee className="w-3 h-3 text-[#94552b]" /> Favorite order:
                  </span>
                  <span className="font-semibold text-[#3b271b]">{rev.favoriteItem}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Review Submission Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#faf7f2] rounded-3xl max-w-md w-full p-6 border border-[#ded0bd] shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif-title font-bold text-xl text-[#271b12]">
                Leave a Guest Review
              </h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="space-y-3.5">
              {/* Star Picker */}
              <div>
                <label className="text-xs font-bold text-[#6d513d] block mb-1">
                  How was your experience?
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => setNewRating(s)}
                      className="p-1 cursor-pointer hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          s <= newRating ? 'fill-amber-500 text-amber-500' : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-semibold text-[#86512a] ml-2">
                    {newRating} of 5 Stars
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#6d513d] block mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="e.g. Jessica Ramos"
                  className="w-full bg-white border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#6d513d] block mb-1">
                  Review Headline
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Sublime coffee and warm welcoming team!"
                  className="w-full bg-white border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#6d513d] block mb-1">
                  Favorite Dish or Drink Ordered
                </label>
                <input
                  type="text"
                  value={newFavoriteItem}
                  onChange={(e) => setNewFavoriteItem(e.target.value)}
                  placeholder="e.g. Honeycomb Sea Salt Latte"
                  className="w-full bg-white border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#6d513d] block mb-1">
                  Your Review Comments
                </label>
                <textarea
                  rows={3}
                  required
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Tell us about the atmosphere, taste, service, or seating..."
                  className="w-full bg-white border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="w-1/3 py-2.5 rounded-xl text-xs font-semibold text-[#664d3b] bg-[#ebdccb] hover:bg-[#dfcebc]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-2/3 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#884e27] hover:bg-[#723f1e] shadow-md cursor-pointer"
                >
                  Post Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
