import React, { useState } from 'react';
import {
  MapPin,
  Clock,
  Phone,
  Mail,
  Instagram,
  Calendar,
  Send,
  CheckCircle2,
  Car,
  Navigation,
  Code,
  Sparkles,
  Users
} from 'lucide-react';
import { CAFE_INFO } from '../data/cafeData';

interface ContactSectionProps {
  onOpenEmbedModal: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenEmbedModal }) => {
  // Table reservation form state
  const [resName, setResName] = useState('');
  const [resEmail, setResEmail] = useState('');
  const [resPhone, setResPhone] = useState('');
  const [resDate, setResDate] = useState('2026-11-02');
  const [resTime, setResTime] = useState('10:30 AM');
  const [resGuests, setResGuests] = useState('2 Guests');
  const [resSeating, setResSeating] = useState('Sunlit Indoor Seating');
  const [resSuccess, setResSuccess] = useState(false);

  // Message form state
  const [msgName, setMsgName] = useState('');
  const [msgEmail, setMsgEmail] = useState('');
  const [msgTopic, setMsgTopic] = useState('General Inquiry');
  const [msgText, setMsgText] = useState('');
  const [msgSuccess, setMsgSuccess] = useState(false);

  const handleReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resName || !resEmail) return;
    setResSuccess(true);
    setTimeout(() => setResSuccess(false), 5000);
  };

  const handleMsgSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgName || !msgText) return;
    setMsgSuccess(true);
    setMsgName('');
    setMsgEmail('');
    setMsgText('');
    setTimeout(() => setMsgSuccess(false), 4500);
  };

  return (
    <section id="contact" className="py-16 bg-[#faf7f2] border-t border-[#e2d5c3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#94552b] bg-[#ebdccb] px-3 py-1 rounded-full border border-[#d8c5b0] inline-flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#94552b]" />
            Find Us & Say Hello
          </span>
          <h2 className="font-serif-title text-3xl sm:text-4xl lg:text-5xl font-bold text-[#271b12] tracking-tight">
            Hours, Location & Reservations
          </h2>
          <p className="text-sm sm:text-base text-[#695445]">
            Nestled on Elmwood Avenue in Heritage Square. Walk-ins are always welcomed, or reserve a table for your weekend brunch.
          </p>
        </div>

        {/* Quick Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Hours */}
          <div className="bg-white p-6 rounded-3xl border border-[#e5d8c6] shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#f2e9dc] text-[#884e27] flex items-center justify-center font-bold">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="font-serif-title font-bold text-lg text-[#271b12]">
              Weekly Hours
            </h3>
            <div className="space-y-2 text-xs text-[#5d4638]">
              {CAFE_INFO.hours.map((h, i) => (
                <div key={i} className="flex justify-between border-b border-[#f3ebde] pb-1.5 last:border-0">
                  <span className="font-medium">{h.days}</span>
                  <span className="font-semibold text-[#291b12]">{h.hours}</span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-[#8d715d] pt-1">
              * Holiday hours may vary slightly; follow our Instagram for real-time announcements.
            </p>
          </div>

          {/* Card 2: Address & Parking */}
          <div className="bg-white p-6 rounded-3xl border border-[#e5d8c6] shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#f2e9dc] text-[#884e27] flex items-center justify-center font-bold">
              <MapPin className="w-5 h-5" />
            </div>
            <h3 className="font-serif-title font-bold text-lg text-[#271b12]">
              Address & Parking
            </h3>
            <p className="text-xs text-[#5d4638] leading-relaxed">
              <strong>{CAFE_INFO.name}</strong><br />
              {CAFE_INFO.address}<br />
              {CAFE_INFO.neighborhood}
            </p>
            <div className="pt-2 text-xs text-[#6e5544] space-y-1">
              <div className="flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-[#884e27]" />
                <span>Dedicated 2-hour free customer parking in rear lot.</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-[#884e27]" />
                <span>2 blocks from Elmwood Metro Station (Blue Line).</span>
              </div>
            </div>
          </div>

          {/* Card 3: Connect & Socials */}
          <div className="bg-white p-6 rounded-3xl border border-[#e5d8c6] shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#f2e9dc] text-[#884e27] flex items-center justify-center font-bold">
              <Phone className="w-5 h-5" />
            </div>
            <h3 className="font-serif-title font-bold text-lg text-[#271b12]">
              Call & Connect
            </h3>
            <div className="space-y-2 text-xs text-[#5d4638]">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#884e27]" />
                <span>{CAFE_INFO.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#884e27]" />
                <span>{CAFE_INFO.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Instagram className="w-3.5 h-3.5 text-[#884e27]" />
                <span>{CAFE_INFO.instagram}</span>
              </div>
            </div>
            <div className="pt-2">
              <button
                onClick={onOpenEmbedModal}
                className="w-full text-xs font-semibold py-2 px-3 rounded-xl bg-[#ebdccb] hover:bg-[#decaba] text-[#634835] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Code className="w-3.5 h-3.5" />
                <span>Get Google Sites Embed Code</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dual Interaction Columns: Table Booking & Interactive Map Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Table Reservation Form (6 cols) */}
          <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-3xl border border-[#e5d8c6] shadow-sm space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#884e27] bg-[#f4ece0] px-2.5 py-1 rounded-full">
                  Instant Table Confirmation
                </span>
                <h3 className="font-serif-title font-bold text-2xl text-[#271b12] mt-2">
                  Reserve a Table or Study Nook
                </h3>
              </div>
              <Calendar className="w-6 h-6 text-[#884e27]" />
            </div>

            <form onSubmit={handleReservationSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                    Your Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={resName}
                    onChange={(e) => setResName(e.target.value)}
                    placeholder="e.g. Liam Taylor"
                    className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                    Email for Confirmation
                  </label>
                  <input
                    type="email"
                    required
                    value={resEmail}
                    onChange={(e) => setResEmail(e.target.value)}
                    placeholder="liam@example.com"
                    className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none focus:ring-1 focus:ring-[#884e27]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                    Party Size
                  </label>
                  <select
                    value={resGuests}
                    onChange={(e) => setResGuests(e.target.value)}
                    className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-2 text-xs text-[#271b12] focus:outline-none"
                  >
                    <option>1 Person (Study Nook)</option>
                    <option>2 Guests</option>
                    <option>3 - 4 Guests</option>
                    <option>5 - 8 Guests (Big Table)</option>
                    <option>Team Event (9+)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={resDate}
                    onChange={(e) => setResDate(e.target.value)}
                    className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-2 text-xs text-[#271b12] focus:outline-none"
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                    Time Slot
                  </label>
                  <select
                    value={resTime}
                    onChange={(e) => setResTime(e.target.value)}
                    className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-2 text-xs text-[#271b12] focus:outline-none"
                  >
                    <option>8:00 AM</option>
                    <option>9:30 AM</option>
                    <option>10:30 AM</option>
                    <option>11:45 AM</option>
                    <option>1:15 PM</option>
                    <option>2:30 PM</option>
                    <option>4:00 PM</option>
                    <option>5:30 PM</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#684f3e] block mb-1">
                  Seating Area Preference
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  {[
                    'Sunlit Indoor Seating',
                    'Garden Patio (Pet Friendly)',
                    'Quiet Wi-Fi Study Nook',
                  ].map((seat) => (
                    <button
                      type="button"
                      key={seat}
                      onClick={() => setResSeating(seat)}
                      className={`py-2 px-2.5 rounded-xl border text-center transition-all cursor-pointer text-[11px] font-medium ${
                        resSeating === seat
                          ? 'bg-[#4a3528] text-white border-[#4a3528]'
                          : 'bg-[#faf7f2] text-[#634e3f] border-[#d8c7b3] hover:border-[#884e27]'
                      }`}
                    >
                      {seat}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#884e27] hover:bg-[#723f1e] active:scale-98 text-white font-semibold py-3 px-4 rounded-xl text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Confirm Free Reservation</span>
              </button>

              {resSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Reservation held for <strong>{resName}</strong> on <strong>{resDate}</strong> at <strong>{resTime}</strong> ({resGuests}, {resSeating})! A confirmation email is on its way.
                  </span>
                </div>
              )}
            </form>
          </div>

          {/* Right: Interactive Cafe Map & Visual Locator (6 cols) */}
          <div className="lg:col-span-6 bg-white rounded-3xl border border-[#e5d8c6] overflow-hidden shadow-sm flex flex-col justify-between">
            {/* Visual Neighborhood Map Rendering */}
            <div className="relative aspect-16/10 bg-[#e4dacb] overflow-hidden">
              {/* Stylized Map Mockup */}
              <div className="absolute inset-0 bg-[#e8dfd3] flex flex-col justify-center items-center p-6 text-center">
                {/* Simulated Street Grid lines */}
                <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#4a3528_1px,transparent_1px)] [background-size:16px_16px]" />
                <div className="absolute w-full h-8 bg-[#d8ccbb] top-1/2 -translate-y-1/2 transform -rotate-6" />
                <div className="absolute w-8 h-full bg-[#d8ccbb] left-1/3 transform -rotate-3" />

                {/* Animated Cafe Pin */}
                <div className="relative z-10 flex flex-col items-center animate-bounce">
                  <div className="w-12 h-12 rounded-full bg-[#884e27] text-white flex items-center justify-center shadow-2xl border-4 border-white">
                    <MapPin className="w-6 h-6 fill-white text-[#884e27]" />
                  </div>
                  <div className="mt-1 px-3 py-1 rounded-full bg-[#2a1c13] text-[#f7efe6] text-xs font-bold shadow-lg">
                    Velvet Roast Cafe & Bakehouse
                  </div>
                </div>

                <div className="absolute bottom-3 left-3 text-[11px] font-medium bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-[#d8c7b3] text-[#5c4738]">
                  Heritage Square & Elmwood Ave
                </div>
              </div>
            </div>

            {/* Direct Message Form / Contact Note */}
            <div className="p-6 space-y-4">
              <h4 className="font-serif-title font-bold text-lg text-[#271b12]">
                Direct Note to the Roaster / Kitchen
              </h4>
              <form onSubmit={handleMsgSubmit} className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    value={msgName}
                    onChange={(e) => setMsgName(e.target.value)}
                    placeholder="Your Name"
                    className="bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none"
                  />
                  <select
                    value={msgTopic}
                    onChange={(e) => setMsgTopic(e.target.value)}
                    className="bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-2.5 py-2 text-xs text-[#271b12] focus:outline-none"
                  >
                    <option>General Inquiry</option>
                    <option>Private Event & Catering</option>
                    <option>Whole Bean Wholesale</option>
                    <option>Dietary / Allergy Question</option>
                  </select>
                </div>

                <textarea
                  rows={2}
                  required
                  value={msgText}
                  onChange={(e) => setMsgText(e.target.value)}
                  placeholder="How can we help you today?"
                  className="w-full bg-[#faf7f2] border border-[#d8c7b3] rounded-xl px-3 py-2 text-xs text-[#271b12] focus:outline-none"
                />

                <button
                  type="submit"
                  className="bg-[#4a3528] hover:bg-[#34241b] text-white text-xs font-semibold py-2 px-4 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message to Cafe Manager</span>
                </button>

                {msgSuccess && (
                  <p className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Message dispatched! We usually reply within 2-3 hours during open hours.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
