import React, { useState } from 'react';
import {
  Code,
  Copy,
  Check,
  X,
  ExternalLink,
  Laptop,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface GoogleSitesEmbedModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleSitesEmbedModal: React.FC<GoogleSitesEmbedModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (!isOpen) return null;

  const currentUrl = window.location.href;
  const embedCode = `<iframe 
  src="${currentUrl}" 
  width="100%" 
  height="850px" 
  style="border:0; border-radius:16px; overflow:hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.08);" 
  title="Velvet Roast Cafe & Bakehouse" 
  allow="clipboard-write"
  loading="lazy">
</iframe>`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(embedCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#faf7f2] rounded-3xl max-w-lg w-full p-6 border border-[#dfceba] shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#ebdccb] text-[#884e27]">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif-title font-bold text-xl text-[#271b12]">
                Google Sites Embed Instructions
              </h3>
              <p className="text-xs text-[#715b4b]">
                Easily embed this cafe site into any Google Sites page
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps for Google Sites */}
        <div className="space-y-3 bg-white p-4 rounded-2xl border border-[#e5d8c6] text-xs text-[#523d2e]">
          <h4 className="font-bold text-[#884e27] uppercase tracking-wider text-[11px] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#884e27]" />
            How to Embed in 3 Simple Steps:
          </h4>
          <ol className="list-decimal list-inside space-y-2 leading-relaxed">
            <li>
              Open your <strong>Google Sites</strong> editor.
            </li>
            <li>
              In the right panel, click <strong>Insert</strong> &gt; <strong>Embed</strong>.
            </li>
            <li>
              Choose <strong>Embed code</strong> (or <strong>By URL</strong>) and paste the snippet below!
            </li>
            <li>
              Drag the blue corners on your Google Sites canvas to expand it to <strong>Full Width</strong>.
            </li>
          </ol>
        </div>

        {/* Option A: Iframe Code */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#624734]">
            <span>Method 1: Embed Code (HTML Iframe)</span>
            <button
              onClick={handleCopyCode}
              className="text-[#884e27] hover:underline flex items-center gap-1 cursor-pointer"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Copied Iframe!' : 'Copy Snippet'}</span>
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-[#2a1c13] text-[#e8c6a5] font-mono text-[11px] overflow-x-auto border border-[#4a3424]">
            {embedCode}
          </pre>
        </div>

        {/* Option B: Direct URL */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#624734]">
            <span>Method 2: Direct Embed URL</span>
            <button
              onClick={handleCopyUrl}
              className="text-[#884e27] hover:underline flex items-center gap-1 cursor-pointer"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'Copied URL!' : 'Copy URL'}</span>
            </button>
          </div>
          <div className="p-2.5 rounded-xl bg-[#f0e6d8] text-[#4a3528] font-mono text-[11px] truncate border border-[#dfceba]">
            {currentUrl}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="w-full bg-[#4a3528] hover:bg-[#34241b] text-white text-xs font-semibold py-2.5 px-4 rounded-xl transition-colors cursor-pointer"
          >
            Got It! Close Window
          </button>
        </div>
      </div>
    </div>
  );
};
