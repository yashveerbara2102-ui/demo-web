import React from 'react';
import {
  Sparkles,
  ArrowRight,
  MapPin,
  Star,
  Coffee,
  HeartHandshake,
  UtensilsCrossed,
  Wifi,
  Clock
} from 'lucide-react';
import { CAFE_INFO } from '../data/cafeData';

interface HeroProps {
  onExploreMenu: () => void;
  onOpenBrewLab: () => void;
  onReserveTable: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreMenu,
  onOpenBrewLab,
  onReserveTable,
}) => {
  return (
    <section id="hero" className="relative overflow-hidden pt-6 pb-14 sm:py-16 bg-[#f5ede2]">
      {/* Decorative Warm Ambient Glows */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-[#dfc09f]/30 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-[#c8986a]/20 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#ebdccb] text-[#5c3e29] border border-[#d8c5b0] shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#a85923]" />
              <span>Small-Batch Roastery & Wood-Fired Bakery</span>
              <span className="hidden sm:inline text-[#a6866d]">•</span>
              <span className="hidden sm:inline text-[#3a291e] font-bold">Downtown Elmwood</span>
            </div>

            <h1 className="font-serif-title text-4xl sm:text-5xl xl:text-6xl font-bold text-[#271b12] tracking-tight leading-[1.12]">
              Where every cup is pulled with craft, and every bite feels like{' '}
              <span className="italic text-[#91542a] underline decoration-[#d9b38c] decoration-wavy decoration-2">
                home.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#5e4b3e] leading-relaxed max-w-2xl mx-auto lg:mx-0">
              Welcome to <strong className="text-[#2c1e15]">Velvet Roast</strong>. We roast single-origin beans daily, bake sourdough croissants at dawn, and serve farm-to-table brunch all day in our warm, sun-lit historic space.
            </p>

            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                onClick={onExploreMenu}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#4a3528] hover:bg-[#38261b] active:scale-95 text-[#fbf7f2] font-semibold text-sm px-6 py-3.5 rounded-xl transition-all shadow-md shadow-[#4a3528]/25 cursor-pointer"
              >
                <UtensilsCrossed className="w-4 h-4 text-[#e2b77c]" />
                <span>Explore Dishes & Drinks</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenBrewLab}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#e8dac7] hover:bg-[#d8c4ae] active:scale-95 text-[#422d1e] font-semibold text-sm px-5 py-3.5 rounded-xl border border-[#cbb399] transition-all cursor-pointer shadow-xs"
              >
                <Sparkles className="w-4 h-4 text-[#a85923]" />
                <span>Custom Brew Lab</span>
                <span className="text-[11px] bg-[#884e27] text-white px-2 py-0.5 rounded-md font-bold uppercase tracking-wider">
                  Special
                </span>
              </button>

              <button
                onClick={onReserveTable}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 text-xs text-[#6e5340] hover:text-[#271b12] font-semibold py-3 px-3 hover:underline cursor-pointer"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Location & Table Booking</span>
              </button>
            </div>

            {/* Micro Highlights Pill Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-[#dfceba]">
              <div className="flex items-center gap-2 text-left">
                <div className="p-1.5 rounded-lg bg-[#ebdccb] text-[#86512a]">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#2a1c13]">4.9 / 5.0 Rating</div>
                  <div className="text-[11px] text-[#715948]">380+ Verified Guests</div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-left">
                <div className="p-1.5 rounded-lg bg-[#ebdccb] text-[#86512a]">
                  <Coffee className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#2a1c13]">Direct-Trade</div>
                  <div className="text-[11px] text-[#715948]">Ethical Small Farms</div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-left">
                <div className="p-1.5 rounded-lg bg-[#ebdccb] text-[#86512a]">
                  <Wifi className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#2a1c13]">Gigabit Wi-Fi</div>
                  <div className="text-[11px] text-[#715948]">Remote Work Hub</div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-left">
                <div className="p-1.5 rounded-lg bg-[#ebdccb] text-[#86512a]">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#2a1c13]">Pet Friendly</div>
                  <div className="text-[11px] text-[#715948]">Sunny Garden Patio</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Card with Real Cafe Collage */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Feature Hero Image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white aspect-4/3 group">
                <img
                  src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=1000&q=80"
                  alt="Cozy Velvet Roast Cafe Ambiance"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#91542a] text-white">
                    Live from Elmwood
                  </span>
                  <p className="text-sm font-semibold mt-1">Sunlit tables, artisan aroma & fresh croissants.</p>
                </div>
              </div>

              {/* Floating Overlapping Card 1 - Coffee Pour */}
              <div className="absolute -bottom-6 -left-6 bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-xl border border-[#ede3d5] flex items-center gap-3 max-w-[210px] hidden sm:flex">
                <img
                  src="https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=200&q=80"
                  alt="Specialty Latte Art"
                  className="w-12 h-12 rounded-xl object-cover"
                />
                <div className="text-left">
                  <div className="text-[10px] text-[#8f694d] font-bold uppercase">Customer Top Pick</div>
                  <div className="text-xs font-bold text-[#241a13] truncate">Honeycomb Latte</div>
                  <div className="text-[11px] text-[#8c5026] font-semibold">$6.25</div>
                </div>
              </div>

              {/* Floating Overlapping Card 2 - Status Pill */}
              <div className="absolute -top-4 -right-4 bg-[#38261b] text-white py-2 px-3.5 rounded-2xl shadow-lg flex items-center gap-2 text-xs font-semibold border border-[#785942]">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Walk-ins & Pickup Open</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
