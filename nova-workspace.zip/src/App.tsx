import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SpecialFeatureBrewLab } from './components/SpecialFeatureBrewLab';
import { MenuSection } from './components/MenuSection';
import { SuggestSection } from './components/SuggestSection';
import { ReviewsSection } from './components/ReviewsSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { GoogleSitesEmbedModal } from './components/GoogleSitesEmbedModal';
import { MenuItem, CartItem } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isEmbedModalOpen, setIsEmbedModalOpen] = useState(false);

  // Cart operations
  const handleAddToCart = (
    item: MenuItem,
    customization?: { size?: 'Regular' | 'Large' | 'Extra Large'; milk?: string; notes?: string }
  ) => {
    const sizeMultiplier =
      customization?.size === 'Extra Large' ? 1.5 : customization?.size === 'Large' ? 1.25 : 1.0;
    const milkAddon = customization?.milk?.includes('$0.75')
      ? 0.75
      : customization?.milk?.includes('$0.85')
      ? 0.85
      : 0;
    const unitPrice = Number((item.price * sizeMultiplier + milkAddon).toFixed(2));

    const cartId = `${item.id}-${customization?.size || 'reg'}-${customization?.milk || 'std'}-${Date.now()}`;

    const newCartItem: CartItem = {
      cartId,
      menuItem: item,
      quantity: 1,
      size: customization?.size,
      milk: customization?.milk,
      notes: customization?.notes,
      itemTotal: unitPrice,
    };

    setCartItems((prev) => [newCartItem, ...prev]);
  };

  const handleAddCustomDrinkToCart = (item: MenuItem, notes: string) => {
    const cartId = `custom-lab-${Date.now()}`;
    const newCartItem: CartItem = {
      cartId,
      menuItem: item,
      quantity: 1,
      notes,
      itemTotal: item.price,
    };
    setCartItems((prev) => [newCartItem, ...prev]);
  };

  const handleAddPairingToCart = (dish: MenuItem, drink: MenuItem, bundlePrice: number) => {
    const bundleId = `bundle-${Date.now()}`;
    // Split the bundle price between the two items
    const dishPortion = Number((bundlePrice * 0.6).toFixed(2));
    const drinkPortion = Number((bundlePrice - dishPortion).toFixed(2));

    const dishItem: CartItem = {
      cartId: `${bundleId}-dish`,
      menuItem: dish,
      quantity: 1,
      notes: 'Part of Curated Mood Pairing Bundle',
      itemTotal: dishPortion,
    };

    const drinkItem: CartItem = {
      cartId: `${bundleId}-drink`,
      menuItem: drink,
      quantity: 1,
      notes: 'Part of Curated Mood Pairing Bundle',
      itemTotal: drinkPortion,
    };

    setCartItems((prev) => [dishItem, drinkItem, ...prev]);
  };

  const handleUpdateQuantity = (cartId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.cartId === cartId) {
            const nextQty = item.quantity + delta;
            if (nextQty <= 0) return null;
            const singleUnitPrice = item.itemTotal / item.quantity;
            return {
              ...item,
              quantity: nextQty,
              itemTotal: Number((singleUnitPrice * nextQty).toFixed(2)),
            };
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (cartId: string) => {
    setCartItems((prev) => prev.filter((i) => i.cartId !== cartId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#faf7f2] text-[#271b12] flex flex-col font-sans selection:bg-[#884e27] selection:text-white antialiased">
      {/* Navigation Bar */}
      <Navbar
        activeSection={activeSection}
        setActiveSection={scrollToSection}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenEmbedModal={() => setIsEmbedModalOpen(true)}
      />

      {/* Main Sections */}
      <main className="flex-1">
        {/* 1. Hero Banner */}
        <Hero
          onExploreMenu={() => scrollToSection('menu')}
          onOpenBrewLab={() => scrollToSection('special')}
          onReserveTable={() => scrollToSection('contact')}
        />

        {/* 2. Special Feature: Custom Brew Lab & Flavor Profiler */}
        <SpecialFeatureBrewLab
          onAddCustomDrinkToCart={handleAddCustomDrinkToCart}
        />

        {/* 3. Comprehensive Menu (All Dishes & Drinks) */}
        <MenuSection
          onAddToCart={handleAddToCart}
        />

        {/* 4. Suggest Section (Mood Pairings & Community Suggestion Box) */}
        <SuggestSection
          onAddPairingToCart={handleAddPairingToCart}
        />

        {/* 5. Customer Reviews & Ratings */}
        <ReviewsSection />

        {/* 6. About Section (Story, Roastery, Ambiance) */}
        <AboutSection />

        {/* 7. Contact, Hours & Table Booking */}
        <ContactSection
          onOpenEmbedModal={() => setIsEmbedModalOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer
        onNavClick={scrollToSection}
        onOpenEmbedModal={() => setIsEmbedModalOpen(true)}
      />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Google Sites Embed Instruction Modal */}
      <GoogleSitesEmbedModal
        isOpen={isEmbedModalOpen}
        onClose={() => setIsEmbedModalOpen(false)}
      />
    </div>
  );
}
