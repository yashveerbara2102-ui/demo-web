import { MenuItem, Review, MoodPairing, CommunitySuggestion } from '../types';

export const CAFE_INFO = {
  name: "Velvet Roast Cafe & Bakehouse",
  tagline: "Small-Batch Roastery, Sourdough Bakes & Wholesome Brunch",
  address: "428 Elmwood Avenue, Heritage Square (Near Central Park)",
  neighborhood: "Downtown Historic District",
  phone: "(555) 284-9382",
  email: "hello@velvetroastcafe.com",
  instagram: "@velvetroastcafe",
  hours: [
    { days: "Monday – Friday", hours: "6:30 AM – 7:00 PM" },
    { days: "Saturday", hours: "7:00 AM – 8:00 PM" },
    { days: "Sunday", hours: "7:30 AM – 6:00 PM" },
    { days: "Kitchen Brunch Cut-off", hours: "Daily until 3:30 PM (Bakery & Coffee open all day)" }
  ],
  amenities: [
    "High-Speed Gigabit Wi-Fi (Work-friendly)",
    "Dog-Friendly Garden Patio",
    "Single-Origin Ethically Sourced Beans",
    "House-Milled Organic Sourdough",
    "Specialty Oat & Almond Milk Bar",
    "Bike Rack & Outdoor Seating"
  ]
};

export const MENU_ITEMS: MenuItem[] = [
  // COFFEE
  {
    id: "c1",
    name: "Velvet Signature Cortado",
    category: "coffee",
    description: "Double ristretto of Ethiopian single-origin pulled over silky textured whole milk in a 4.5oz Gibraltar glass.",
    price: 4.85,
    image: "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=800&q=80",
    popular: true,
    isSpecialty: true,
    calories: 120,
    prepTime: "3 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "c2",
    name: "Honeycomb Sea Salt Latte",
    category: "coffee",
    description: "House-made organic honeycomb candy melted into creamy microfoam espresso, dusted with Maldon sea salt flakes.",
    price: 6.25,
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=800&q=80",
    popular: true,
    isSpecialty: true,
    calories: 260,
    prepTime: "4 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "c3",
    name: "18-Hour Kyoto Slow Cold Brew",
    category: "coffee",
    description: "Drip-extracted drop by drop over 18 hours using Colombian Supremo beans. Notes of dark chocolate, berry, and roasted hazelnut.",
    price: 5.50,
    image: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 15,
    prepTime: "1 min",
    dietary: ["vegan", "gluten-free", "dairy-free"],
    customizable: true
  },
  {
    id: "c4",
    name: "Spanish Vanilla Cardamom Latte",
    category: "coffee",
    description: "Sweetened condensed milk infused with freshly crushed green cardamom pods and Madagascar bourbon vanilla bean.",
    price: 6.10,
    image: "https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?auto=format&fit=crop&w=800&q=80",
    calories: 280,
    prepTime: "3 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "c5",
    name: "Classic Flat White",
    category: "coffee",
    description: "Velvety micro-textured milk poured expertly over a double shot of our medium-dark house roast.",
    price: 4.95,
    image: "https://images.unsplash.com/photo-1577968897966-3d4325b36b61?auto=format&fit=crop&w=800&q=80",
    calories: 140,
    prepTime: "3 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "c6",
    name: "Nitro Brown Sugar Cold Brew",
    category: "coffee",
    description: "Nitrogen-infused cold brew poured on draft with a cascading stout-like head, swirled with molasses brown sugar syrup.",
    price: 5.95,
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
    calories: 90,
    prepTime: "2 mins",
    dietary: ["vegan", "dairy-free"],
    customizable: true
  },

  // TEAS & REFRESHERS
  {
    id: "t1",
    name: "Ceremonial Uji Matcha Latte",
    category: "tea",
    description: "First-harvest stone-ground Japanese ceremonial matcha whisked with oat milk and a touch of agave nectar.",
    price: 5.85,
    image: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 180,
    prepTime: "4 mins",
    dietary: ["vegan", "dairy-free"],
    customizable: true
  },
  {
    id: "t2",
    name: "Hibiscus Peach Sparkler",
    category: "tea",
    description: "Tart organic Egyptian hibiscus tea brewed cold, shaken with white peach purée, mint sprigs, and sparkling mineral water.",
    price: 5.25,
    image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=800&q=80",
    popular: false,
    calories: 95,
    prepTime: "2 mins",
    dietary: ["vegan", "gluten-free", "dairy-free"],
    customizable: false
  },
  {
    id: "t3",
    name: "Spiced Masala Chai",
    category: "tea",
    description: "Assam black tea simmered in copper pots with whole cinnamon quills, black pepper, star anise, ginger, and oat milk.",
    price: 5.40,
    image: "https://images.unsplash.com/photo-1561336313-0bd5e0b27ec8?auto=format&fit=crop&w=800&q=80",
    calories: 210,
    prepTime: "4 mins",
    dietary: ["vegan", "dairy-free"],
    customizable: true
  },

  // BAKERY & PASTRIES
  {
    id: "b1",
    name: "Toasted Almond Twice-Baked Croissant",
    category: "bakery",
    description: "Layered French butter croissant filled with frangipane almond cream, topped with roasted sliced almonds and powdered sugar.",
    price: 5.25,
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 420,
    prepTime: "Ready to serve",
    dietary: ["vegetarian"],
    customizable: false
  },
  {
    id: "b2",
    name: "Blueberry Earl Grey Scone",
    category: "bakery",
    description: "Crumbly golden cream scone studded with fresh wild blueberries and drizzled with bergamot Earl Grey tea glaze.",
    price: 4.45,
    image: "https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?auto=format&fit=crop&w=800&q=80",
    calories: 340,
    prepTime: "Ready to serve",
    dietary: ["vegetarian"],
    customizable: false
  },
  {
    id: "b3",
    name: "San Sebastián Basque Burnt Cheesecake",
    category: "bakery",
    description: "Caramelized crust with a molten, ultra-creamy interior. Served with a dollop of raspberry coulis.",
    price: 6.95,
    image: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 460,
    prepTime: "Ready to serve",
    dietary: ["vegetarian", "gluten-free"],
    customizable: false
  },
  {
    id: "b4",
    name: "Cinnamon Cardamom Morning Bun",
    category: "bakery",
    description: "Laminated flaky brioche dough rolled in raw sugar, Ceylon cinnamon, and aromatic ground cardamom.",
    price: 4.95,
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80",
    calories: 380,
    prepTime: "Ready to serve",
    dietary: ["vegetarian"],
    customizable: false
  },

  // BREAKFAST & BRUNCH
  {
    id: "br1",
    name: "Smoked Salmon & Herbed Chevre Tartine",
    category: "breakfast",
    description: "Warm house-toasted country sourdough, whipped goat cheese, wild smoked salmon, caper berries, pickled shallots, and fresh dill.",
    price: 13.95,
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 490,
    prepTime: "8 mins",
    dietary: [],
    customizable: true
  },
  {
    id: "br2",
    name: "Avocado & Poached Egg Sourdough",
    category: "breakfast",
    description: "Crushed Hass avocado with lime, Aleppo chili flakes, toasted pumpkin seeds, radish roses, and two free-range pasture eggs on seeded sourdough.",
    price: 12.50,
    image: "https://images.unsplash.com/photo-1588137378633-dea1336ce1e2?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 440,
    prepTime: "7 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "br3",
    name: "North African Baked Shakshuka",
    category: "breakfast",
    description: "Cast iron skillet of spiced San Marzano tomato & roasted pepper ragù, poached eggs, creamy feta crumbles, and warm pita bread.",
    price: 14.25,
    image: "https://images.unsplash.com/photo-1590412200988-a436970781fa?auto=format&fit=crop&w=800&q=80",
    calories: 520,
    prepTime: "10 mins",
    dietary: ["vegetarian"],
    customizable: true
  },
  {
    id: "br4",
    name: "Superfood Acai & Dragonfruit Bowl",
    category: "breakfast",
    description: "Frozen organic acai & pitaya smoothie base topped with toasted chia granola, sliced kiwi, banana, cacao nibs, and local wildflower honey.",
    price: 11.50,
    image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=800&q=80",
    calories: 380,
    prepTime: "5 mins",
    dietary: ["vegan", "gluten-free", "dairy-free"],
    customizable: true
  },

  // LUNCH & SAVORY
  {
    id: "l1",
    name: "Tuscan Grilled Chicken & Pesto Panini",
    category: "lunch",
    description: "Herb-marinated chicken breast, sun-dried tomato pesto, buffalo mozzarella, baby arugula, pressed on artisanal ciabatta.",
    price: 13.50,
    image: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80",
    popular: true,
    calories: 610,
    prepTime: "8 mins",
    dietary: [],
    customizable: true
  },
  {
    id: "l2",
    name: "Roasted Mediterranean Grain Bowl",
    category: "lunch",
    description: "Tricolor warm quinoa, roasted spiced chickpeas, kalamata olives, cucumbers, cherry tomatoes, kalamata dressing, and green goddess tahini drizzle.",
    price: 12.80,
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
    calories: 450,
    prepTime: "6 mins",
    dietary: ["vegan", "gluten-free", "dairy-free"],
    customizable: true
  },
  {
    id: "l3",
    name: "Rustic Fire-Roasted Tomato & Basil Bisque",
    category: "lunch",
    description: "Simmered San Marzano tomatoes, sweet garlic, coconut cream, fresh sweet basil. Served with a mini aged cheddar sourdough toastie.",
    price: 9.75,
    image: "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=800&q=80",
    calories: 390,
    prepTime: "5 mins",
    dietary: ["vegetarian"],
    customizable: true
  }
];

export const REVIEWS_DATA: Review[] = [
  {
    id: "r1",
    author: "Elena Rostova",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
    rating: 5,
    date: "3 days ago",
    title: "Best coffeehouse in the neighborhood by far!",
    comment: "The Honeycomb Sea Salt Latte paired with the Almond Croissant is pure bliss. The staff knows their coffee craft, the natural light is stunning, and the Wi-Fi is super fast for remote work.",
    favoriteItem: "Honeycomb Sea Salt Latte",
    verified: true
  },
  {
    id: "r2",
    author: "Marcus Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
    rating: 5,
    date: "1 week ago",
    title: "Their Custom Brew Lab is an absolute game-changer",
    comment: "I used their interactive Brew Lab on the site before visiting and ordered a Nitro cold brew with oat cream and cardamom. When I got to the counter they made it exactly to my recipe. Outstanding service!",
    favoriteItem: "Nitro Brown Sugar Cold Brew",
    verified: true
  },
  {
    id: "r3",
    author: "Sarah Jenkins",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
    rating: 5,
    date: "2 weeks ago",
    title: "Incredible weekend brunch vibe",
    comment: "Came here on Saturday with my pup for outdoor patio seating. The Shakshuka had incredible depth of flavor and the sourdough was still warm from the oven. Will be back every weekend.",
    favoriteItem: "North African Baked Shakshuka",
    verified: true
  },
  {
    id: "r4",
    author: "Devon Miller",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80",
    rating: 4,
    date: "3 weeks ago",
    title: "Top tier matcha and cozy ambiance",
    comment: "Real ceremonial grade matcha without excessive sugar. They take dietary preferences seriously—great oat milk options. Gets busy around 10am so order pickup online to skip the line!",
    favoriteItem: "Ceremonial Uji Matcha Latte",
    verified: true
  }
];

export const MOOD_PAIRINGS: MoodPairing[] = [
  {
    id: "p1",
    mood: "Need a Serious Morning Spark",
    iconName: "Zap",
    badge: "Energizer",
    dishName: "Avocado & Poached Egg Sourdough",
    drinkName: "Velvet Signature Cortado",
    dishImage: "https://images.unsplash.com/photo-1588137378633-dea1336ce1e2?auto=format&fit=crop&w=500&q=80",
    drinkImage: "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=500&q=80",
    price: 17.35,
    bundlePrice: 15.50,
    description: "High-protein poached eggs with healthy fats balanced by rich Ethiopian double-shot cortado to power through your morning.",
    tags: ["High Protein", "Strong Caffeine", "Barista Favorite"]
  },
  {
    id: "p2",
    mood: "Sweet Afternoon Self-Care Treat",
    iconName: "Heart",
    badge: "Indulgent",
    dishName: "Toasted Almond Croissant",
    drinkName: "Honeycomb Sea Salt Latte",
    dishImage: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=500&q=80",
    drinkImage: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=500&q=80",
    price: 11.50,
    bundlePrice: 9.95,
    description: "Warm flaky frangipane butter pastry dipped into sea salt honey microfoam. The ultimate 3 PM mood booster.",
    tags: ["Decadent", "Pastry Pair", "Top Rated"]
  },
  {
    id: "p3",
    mood: "Clean, Zen & Refreshing Focus",
    iconName: "Leaf",
    badge: "Healthy & Clean",
    dishName: "Superfood Acai Bowl",
    drinkName: "Ceremonial Uji Matcha Latte",
    dishImage: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=500&q=80",
    drinkImage: "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=500&q=80",
    price: 17.35,
    bundlePrice: 15.20,
    description: "L-theanine from first-harvest matcha gives calm jitter-free alertness, paired with antioxidant rich berries and chia granola.",
    tags: ["Vegan", "Superfoods", "Clean Energy"]
  },
  {
    id: "p4",
    mood: "Satisfying Hearty Lunch Break",
    iconName: "Coffee",
    badge: "Hearty Meal",
    dishName: "Tuscan Grilled Chicken Panini",
    drinkName: "18-Hour Kyoto Slow Cold Brew",
    dishImage: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=500&q=80",
    drinkImage: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=500&q=80",
    price: 19.00,
    bundlePrice: 16.95,
    description: "Crispy grilled ciabatta with chicken and mozzarella cuts cleanly through the chocolatey crispness of our slow cold brew.",
    tags: ["Filling", "Savory", "Quick Prep"]
  }
];

export const INITIAL_COMMUNITY_SUGGESTIONS: CommunitySuggestion[] = [
  {
    id: "cs1",
    title: "Pistachio Rose Cardamom Cold Foam",
    category: "Drink Creation",
    author: "Zoe K.",
    date: "4 days ago",
    description: "Add a creamy pistachio milk cold foam with natural rose water mist on top of iced cold brews for spring!",
    upvotes: 42,
    status: "Barista Testing"
  },
  {
    id: "cs2",
    title: "Gluten-Free Lemon Poppy Sourdough Muffins",
    category: "Bakery",
    author: "Liam S.",
    date: "1 week ago",
    description: "A moist gluten-free muffin option with lemon curd center. There are limited gluten-free sweet breakfast items right now.",
    upvotes: 29,
    status: "Coming Next Season"
  },
  {
    id: "cs3",
    title: "Weekend Board Game & Acoustic Sunset Sessions",
    category: "Events & Vibe",
    author: "Maya Patel",
    date: "2 weeks ago",
    description: "Host Sunday 5 PM acoustic guitar evenings with local musicians and artisanal pour-over tastings.",
    upvotes: 56,
    status: "In Review"
  }
];
