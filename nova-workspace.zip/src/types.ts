export type Category = 'coffee' | 'tea' | 'bakery' | 'breakfast' | 'lunch' | 'seasonal';

export interface MenuItem {
  id: string;
  name: string;
  category: Category;
  description: string;
  price: number;
  image: string;
  popular?: boolean;
  isSpecialty?: boolean;
  calories?: number;
  prepTime?: string;
  dietary?: ('vegan' | 'vegetarian' | 'gluten-free' | 'dairy-free')[];
  customizable?: boolean;
}

export interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  favoriteItem?: string;
  verified: boolean;
}

export interface MoodPairing {
  id: string;
  mood: string;
  iconName: string;
  badge: string;
  dishName: string;
  drinkName: string;
  dishImage: string;
  drinkImage: string;
  price: number;
  bundlePrice: number;
  description: string;
  tags: string[];
}

export interface CommunitySuggestion {
  id: string;
  title: string;
  category: string;
  author: string;
  date: string;
  description: string;
  upvotes: number;
  hasUpvoted?: boolean;
  status: 'In Review' | 'Barista Testing' | 'Coming Next Season' | 'Added to Menu';
}

export interface CartItem {
  cartId: string;
  menuItem: MenuItem;
  quantity: number;
  size?: 'Regular' | 'Large' | 'Extra Large';
  milk?: string;
  sweetness?: string;
  temperature?: 'Hot' | 'Iced';
  notes?: string;
  itemTotal: number;
}

export interface CustomBrewConfig {
  base: string;
  roast: string;
  milk: string;
  sweetness: string;
  flavors: string[];
  temperature: 'Hot' | 'Iced' | 'Nitro Cold';
  topping: string;
  customName: string;
}
